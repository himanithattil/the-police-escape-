# AI Face Detection – Integration Notes

## What was added (non-destructive)

| Item | Path | Change type |
|------|------|-------------|
| FastAPI microservice | `server/face-service/` | **New folder** |
| React page | `client/src/pages/AIFaceDetection.tsx` | **New file** |
| Route | `client/src/App.tsx` | One import + one `<Route>` |
| Nav item | `client/src/components/CommandLayout.tsx` | One nav entry + icon + shared-session filter |
| Env docs | `.env.example` | Appended comments |

**No existing routes, tRPC routers, schema, auth, Ollama detection, or database tables were modified.**

## How to run

### 1. Start Sentinel as usual
```bash
cd sentinel-project
pnpm install   # or npm / yarn
pnpm dev
```

### 2. Start the Face service (separate terminal)
```bash
cd sentinel-project/server/face-service
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
# optional real keys:
cp .env.example .env   # then edit
uvicorn main:app --host 0.0.0.0 --port 8100 --reload
```

### 3. Open the UI
Navigate to **AI Face Detection** in the sidebar (right after Live Detection)  
or go directly to `/face-detect`.

## Modes

- **Real** – when SerpAPI + Cloudinary keys are set **and** DeepFace models are available.
- **Demo** – automatic fallback when keys or models are missing. UI still works with simulated matches and a fake Sepolia proof.

## Environment variables

Frontend (Vite):
- `VITE_FACE_SERVICE_URL` – default `http://127.0.0.1:8100`

Face service (`server/face-service/.env`):
- `SERPAPI_KEY`
- `CLOUDINARY_CLOUD_NAME` / `CLOUDINARY_API_KEY` / `CLOUDINARY_API_SECRET`
- `CONTRACT_ADDRESS` / `WALLET_PRIVATE_KEY`
- `SEPOLIA_RPC` (optional)

## Viability notes

- DeepFace downloads models on first real run (can take several minutes).
- SerpAPI and Cloudinary are paid external services; without them the service stays in demo mode.
- The custom Sepolia client is intentionally lightweight; public RPCs can rate-limit.
- All heavy Python work is isolated so the main Sentinel Node process stays untouched.
