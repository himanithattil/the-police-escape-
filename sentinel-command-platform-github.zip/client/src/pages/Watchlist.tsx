import {
  Archive,
  ArrowRight,
  BadgeAlert,
  BadgeCheck,
  Check,
  CheckCircle2,
  CircleAlert,
  Clock3,
  FileCheck2,
  FilePlus2,
  Filter,
  Flame,
  Image as ImageIcon,
  LockKeyhole,
  Plus,
  Radio,
  Search,
  ShieldAlert,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  Upload,
  UserRoundSearch,
  X,
} from "lucide-react";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { DataState, PageHeading, PriorityBadge, SectionTitle, StatusBadge } from "@/components/CommandPrimitives";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  getCamera,
  getPersonDisplay,
  getPlateDisplay,
  getStoredCases,
  mergeCasesWithStorage,
  saveCustomCase,
  updateStoredCase,
  deleteStoredCase,
  type AlertRecord,
  type CameraRecord,
  type CaseEvidenceItem,
  type ResolutionEvidenceType,
  type ResolutionOutcome,
  type SubjectType,
  type WatchlistCase,
} from "@/lib/operations";
import { trpc } from "@/lib/trpc";
import { isJudgeDemo } from "@/lib/demo";
import { getSharedToken } from "@/lib/share";

type ResolutionForm = { outcome: ResolutionOutcome; evidenceType: ResolutionEvidenceType; evidenceReference: string; evidenceSummary: string };
type VerificationAction = "verify" | "reject" | "request_more_evidence";
type FilterTab = "all" | "high_alert" | "active" | "unsolved" | "resolved" | "vehicle" | "person";
type SortOption = "high_alert" | "recent" | "priority" | "alpha";

function outcomeLabel(outcome: ResolutionOutcome) {
  return outcome === "vehicle_found" ? "Vehicle found" : outcome === "person_found" ? "Person found" : "Case solved";
}

function evidenceLabel(evidenceType: ResolutionEvidenceType) {
  return evidenceType === "cross_camera" ? "Cross-camera evidence" : evidenceType === "field_confirmation" ? "Field confirmation" : "Official case record";
}

function defaultOutcome(subjectType: WatchlistCase["subjectType"]): ResolutionOutcome {
  return subjectType === "vehicle" ? "vehicle_found" : "person_found";
}

export default function Watchlist() {
  const [tab, setTab] = useState<FilterTab>("all");
  const [sortBy, setSortBy] = useState<SortOption>("high_alert");
  const [search, setSearch] = useState("");
  const [selectedCaseId, setSelectedCaseId] = useState("CASE-48");
  const [resolutionMessage, setResolutionMessage] = useState("");
  const [resolutionForm, setResolutionForm] = useState<ResolutionForm>({ outcome: "vehicle_found", evidenceType: "cross_camera", evidenceReference: "", evidenceSummary: "" });
  const [verificationMessage, setVerificationMessage] = useState("");
  const [localUpdateNonce, setLocalUpdateNonce] = useState(0);

  // New Case Modal State
  const [isAddCaseOpen, setIsAddCaseOpen] = useState(false);
  const [newCase, setNewCase] = useState({
    caseReference: `GJ-CRIM-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
    subject: "",
    subjectType: "vehicle" as SubjectType,
    category: "Stolen vehicle",
    priority: "high" as "high" | "medium" | "low",
    status: "active" as "active" | "unsolved" | "resolved",
    isHighAlert: true,
    owner: "Ahmedabad Crime Branch",
    incidentDistrict: "Ahmedabad",
    notes: "",
    evidenceReference: `EVID-${Date.now().toString().slice(-4)}`,
    evidenceType: "cross_camera" as ResolutionEvidenceType,
    evidenceSummary: "",
    evidencePhotoUrl: "",
  });

  // Add Evidence to Selected Case Modal State
  const [isAddEvidenceOpen, setIsAddEvidenceOpen] = useState(false);
  const [newEvidence, setNewEvidence] = useState({
    title: "Surveillance Snapshot",
    reference: `EVID-ADD-${Math.floor(1000 + Math.random() * 9000)}`,
    type: "Cross-Camera ANPR",
    summary: "",
    photoUrl: "",
  });

  const { user } = useAuth();
  const judgeDemo = isJudgeDemo();
  const overview = trpc.operations.overview.useQuery(undefined, { refetchInterval: 15_000 });
  const sharedToken = getSharedToken();
  const sharedAccess = trpc.share.inspect.useQuery({ token: sharedToken ?? "" }, { enabled: Boolean(sharedToken), retry: false, refetchInterval: 60_000 });
  const sharedReadOnly = Boolean(sharedToken && sharedAccess.data?.valid);
  const utils = trpc.useUtils();

  const acknowledgeMutation = trpc.operations.alerts.acknowledge.useMutation({ onSuccess: () => utils.operations.overview.invalidate() });
  const resolveMutation = trpc.operations.cases.resolve.useMutation({
    onSuccess: (result) => {
      utils.operations.overview.invalidate();
      updateStoredCase(selectedCaseId, { status: "resolved", resolutionOutcome: result.outcome });
      setLocalUpdateNonce((n) => n + 1);
      setResolutionMessage(`${outcomeLabel(result.outcome)} officially recorded for ${result.caseReference}. Evidence retained for forensic court audit.`);
    },
    onError: (error) => setResolutionMessage(error.message),
  });

  const verificationMutation = trpc.operations.cases.verify.useMutation({
    onSuccess: () => {
      utils.operations.overview.invalidate();
      setVerificationMessage("Case approval decision signed and committed to the operational audit ledger.");
    },
    onError: (error) => setVerificationMessage(error.message),
  });

  const rawCases = useMemo(() => {
    const fromApi = (overview.data?.watchlistCases ?? []) as WatchlistCase[];
    return mergeCasesWithStorage(fromApi);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [overview.data?.watchlistCases, localUpdateNonce]);

  const cameras = (overview.data?.cameras ?? []) as CameraRecord[];
  const alerts = (overview.data?.alerts ?? []).map((item) => ({ ...item, confidence: item.confidence / 10 })) as AlertRecord[];

  // Filter cases based on search and tab
  const filteredCases = useMemo(() => {
    let list = [...rawCases];

    // High Alert defaults for seed cases if not explicitly set
    list = list.map((c) => {
      if (c.isHighAlert === undefined) {
        return { ...c, isHighAlert: c.priority === "high" || c.id === "CASE-48" || c.id === "PER-19" };
      }
      return c;
    });

    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter((c) =>
        `${c.subject} ${c.caseReference} ${c.category} ${c.owner} ${c.notes} ${c.incidentDistrict ?? ""}`
          .toLowerCase()
          .includes(q),
      );
    }

    if (tab === "high_alert") {
      list = list.filter((c) => c.isHighAlert);
    } else if (tab === "active") {
      list = list.filter((c) => c.status === "active");
    } else if (tab === "unsolved") {
      list = list.filter((c) => c.status === "unsolved");
    } else if (tab === "resolved") {
      list = list.filter((c) => c.status === "resolved");
    } else if (tab === "vehicle") {
      list = list.filter((c) => c.subjectType === "vehicle");
    } else if (tab === "person") {
      list = list.filter((c) => c.subjectType === "person");
    }

    // Sort cases
    if (sortBy === "high_alert") {
      list.sort((a, b) => {
        if (a.isHighAlert && !b.isHighAlert) return -1;
        if (!a.isHighAlert && b.isHighAlert) return 1;
        const pOrder: Record<string, number> = { high: 3, medium: 2, low: 1 };
        return (pOrder[b.priority] ?? 0) - (pOrder[a.priority] ?? 0);
      });
    } else if (sortBy === "priority") {
      const pOrder: Record<string, number> = { high: 3, medium: 2, low: 1 };
      list.sort((a, b) => (pOrder[b.priority] ?? 0) - (pOrder[a.priority] ?? 0));
    } else if (sortBy === "recent") {
      list.sort((a, b) => b.lastUpdate.localeCompare(a.lastUpdate));
    } else if (sortBy === "alpha") {
      list.sort((a, b) => a.subject.localeCompare(b.subject));
    }

    return list;
  }, [rawCases, search, tab, sortBy]);

  const selectedCase = useMemo(() => {
    return filteredCases.find((item) => item.id === selectedCaseId) ?? filteredCases[0] ?? rawCases[0];
  }, [filteredCases, selectedCaseId, rawCases]);

  useEffect(() => {
    if (selectedCase) {
      setResolutionForm((current) => ({ ...current, outcome: defaultOutcome(selectedCase.subjectType) }));
    }
  }, [selectedCase]);

  // Counts for tabs
  const counts = useMemo(() => {
    const list = rawCases.map((c) => ({
      ...c,
      isHighAlert: c.isHighAlert ?? (c.priority === "high" || c.id === "CASE-48" || c.id === "PER-19"),
    }));
    return {
      all: list.length,
      high_alert: list.filter((c) => c.isHighAlert).length,
      active: list.filter((c) => c.status === "active").length,
      unsolved: list.filter((c) => c.status === "unsolved").length,
      resolved: list.filter((c) => c.status === "resolved").length,
      vehicle: list.filter((c) => c.subjectType === "vehicle").length,
      person: list.filter((c) => c.subjectType === "person").length,
    };
  }, [rawCases]);

  if (overview.isLoading && !rawCases.length) {
    return <DataState mode="loading" title="Loading case intelligence" detail="Synchronising the persisted watchlist, alert ledger, and case history." />;
  }

  const caseAlerts = alerts.filter((alert) => alert.caseReference === selectedCase?.caseReference);
  const outcomeIsValid = Boolean(selectedCase) && (resolutionForm.outcome === "case_solved" || resolutionForm.outcome === defaultOutcome(selectedCase!.subjectType));
  const evidenceIsComplete = resolutionForm.evidenceReference.trim().length >= 3 && resolutionForm.evidenceSummary.trim().length >= 10;
  const resolutionReady = outcomeIsValid && evidenceIsComplete && !resolveMutation.isPending;

  function toggleHighAlert(caseItem: WatchlistCase) {
    const nextState = !caseItem.isHighAlert;
    updateStoredCase(caseItem.id, { isHighAlert: nextState });
    setLocalUpdateNonce((n) => n + 1);
    setResolutionMessage(nextState ? `🚨 Case ${caseItem.caseReference} escalated to HIGH ALERT.` : `Case ${caseItem.caseReference} High Alert status cleared.`);
  }

  function handleStatusChange(caseItem: WatchlistCase, newStatus: "active" | "unsolved" | "resolved") {
    updateStoredCase(caseItem.id, { status: newStatus });
    setLocalUpdateNonce((n) => n + 1);
    setResolutionMessage(`Case ${caseItem.caseReference} status changed to ${newStatus.toUpperCase()}.`);
  }

  function handleCreateCase(e: FormEvent) {
    e.preventDefault();
    if (!newCase.subject.trim()) {
      alert("Please enter a suspect name or vehicle plate number.");
      return;
    }

    const createdId = `CASE-${Date.now().toString().slice(-4)}`;
    const newCaseRecord: WatchlistCase = {
      id: createdId,
      caseReference: newCase.caseReference.trim(),
      subject: newCase.subject.trim().toUpperCase(),
      subjectType: newCase.subjectType,
      category: newCase.category,
      priority: newCase.priority,
      status: newCase.status,
      verificationStatus: "verified",
      owner: newCase.owner.trim() || "Duty Desk",
      incidentDistrict: newCase.incidentDistrict,
      lastUpdate: "Just registered",
      notes: newCase.notes.trim() || "Police case registered via Sentinel Command Console.",
      isHighAlert: newCase.isHighAlert,
      evidencePhotoUrl: newCase.evidencePhotoUrl.trim() || undefined,
      evidenceAttachments: newCase.evidenceSummary
        ? [
            {
              id: `EVID-${Date.now()}`,
              title: "Primary Intake Evidence",
              reference: newCase.evidenceReference,
              summary: newCase.evidenceSummary,
              timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
              type: newCase.evidenceType,
              photoUrl: newCase.evidencePhotoUrl.trim() || undefined,
            },
          ]
        : [],
    };

    saveCustomCase(newCaseRecord);
    setLocalUpdateNonce((n) => n + 1);
    setSelectedCaseId(createdId);
    setIsAddCaseOpen(false);
    setResolutionMessage(`Case ${newCaseRecord.caseReference} (${newCaseRecord.subject}) successfully created and registered.`);
  }

  function handleAddEvidence(e: FormEvent) {
    e.preventDefault();
    if (!selectedCase) return;
    if (!newEvidence.summary.trim()) {
      alert("Please provide an evidence description or forensic finding.");
      return;
    }

    const item: CaseEvidenceItem = {
      id: `EVID-${Date.now()}`,
      title: newEvidence.title.trim() || "Evidence Sighting",
      reference: newEvidence.reference.trim(),
      type: newEvidence.type,
      summary: newEvidence.summary.trim(),
      timestamp: `${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} IST`,
      photoUrl: newEvidence.photoUrl.trim() || undefined,
    };

    const currentList = selectedCase.evidenceAttachments ?? [];
    const updatedList = [item, ...currentList];

    updateStoredCase(selectedCase.id, {
      evidenceAttachments: updatedList,
      evidencePhotoUrl: item.photoUrl || selectedCase.evidencePhotoUrl,
    });
    setLocalUpdateNonce((n) => n + 1);
    setIsAddEvidenceOpen(false);
    setResolutionMessage(`Evidence record ${item.reference} added to ${selectedCase.caseReference}.`);
  }

  async function verifyCase(action: VerificationAction) {
    if (!selectedCase) return;
    const reason = window.prompt(`${action.replaceAll("_", " ")} reason for ${selectedCase.caseReference}:`, "Analyst reviewed linked detections and case context.");
    if (!reason) return;
    if (sharedReadOnly) {
      setVerificationMessage("This is a read-only shared view. Verification changes are disabled.");
      return;
    }

    const verificationStatus = action === "verify" ? "verified" : action === "reject" ? "rejected" : "more_evidence";
    updateStoredCase(selectedCase.id, { verificationStatus });
    setLocalUpdateNonce((n) => n + 1);

    if (judgeDemo || !user) {
      verificationMutation.mutate({ recordType: "watchlist_case", recordId: selectedCase.id, action, reason, demo: true });
    } else {
      verificationMutation.mutate({ recordType: "watchlist_case", recordId: selectedCase.id, action, reason });
    }
  }

  function submitResolution(event: FormEvent) {
    event.preventDefault();
    if (!selectedCase) return;
    if (sharedReadOnly) {
      setResolutionMessage("This is a read-only shared view. Case changes are disabled.");
      return;
    }
    if (!outcomeIsValid) {
      setResolutionMessage(`Choose an outcome that matches this ${selectedCase.subjectType} case.`);
      return;
    }
    if (!evidenceIsComplete) {
      setResolutionMessage("Add an evidence reference and a detailed evidence summary before resolving.");
      return;
    }

    const resolution = { ...resolutionForm };
    updateStoredCase(selectedCase.id, {
      status: "resolved",
      resolutionOutcome: resolution.outcome,
      resolutionEvidenceType: resolution.evidenceType,
      resolutionEvidenceReference: resolution.evidenceReference,
      resolutionEvidenceSummary: resolution.evidenceSummary,
      resolvedBy: user?.name ?? "Lead Investigating Officer",
      resolvedAt: new Date().toISOString(),
    });
    setLocalUpdateNonce((n) => n + 1);

    if (judgeDemo || !user) {
      resolveMutation.mutate({ id: selectedCase.id, ...resolution, demo: true });
    } else {
      resolveMutation.mutate({ id: selectedCase.id, ...resolution });
    }
  }

  return (
    <div className="page-stack">
      <PageHeading
        eyebrow="LAW ENFORCEMENT CASE INTELLIGENCE"
        title={
          <>
            Active Case Register &amp;
            <br />
            <span>Criminal Investigation Hub.</span>
          </>
        }
        description="Comprehensive case tracking for police officers. Classify solved vs. unsolved cases, flag urgent threats with high-alert marks, attach cross-camera evidence, and sort by priority."
        actions={
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsAddCaseOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider rounded transition-all shadow-lg hover:shadow-blue-500/20 active:scale-95"
            >
              <Plus size={16} />
              <span>Add New Case / FIR</span>
            </button>
            <div className={`case-heading-actions ${judgeDemo ? "case-heading-actions-demo" : ""}`}>
              <BadgeCheck size={18} />
              <div>
                <strong>{judgeDemo ? "HACKATHON DEMO MODE" : "PERSISTED WORKFLOW"}</strong>
                <span>Instant police trial · writes enabled</span>
              </div>
            </div>
          </div>
        }
      />

      {/* Case Filter Tabs & Sorting Toolbar */}
      <section className="bg-slate-900/80 border border-slate-700/60 p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            className={`px-3 py-1.5 text-xs font-semibold rounded flex items-center gap-1.5 transition-colors ${
              tab === "all" ? "bg-blue-600 text-white shadow" : "bg-slate-800 text-slate-300 hover:bg-slate-700"
            }`}
            onClick={() => setTab("all")}
          >
            <span>All Cases</span>
            <span className="px-1.5 py-0.2 bg-black/30 rounded text-[10px]">{counts.all}</span>
          </button>
          <button
            className={`px-3 py-1.5 text-xs font-semibold rounded flex items-center gap-1.5 transition-colors ${
              tab === "high_alert"
                ? "bg-rose-600 text-white shadow ring-2 ring-rose-400/50"
                : "bg-slate-800 text-rose-300 hover:bg-slate-700"
            }`}
            onClick={() => setTab("high_alert")}
          >
            <Flame size={13} className="text-rose-400 animate-pulse" />
            <span>High Alert</span>
            <span className="px-1.5 py-0.2 bg-rose-950/60 rounded text-[10px] font-bold text-rose-200">{counts.high_alert}</span>
          </button>
          <button
            className={`px-3 py-1.5 text-xs font-semibold rounded flex items-center gap-1.5 transition-colors ${
              tab === "active" ? "bg-amber-600 text-white shadow" : "bg-slate-800 text-amber-300 hover:bg-slate-700"
            }`}
            onClick={() => setTab("active")}
          >
            <Radio size={13} className="text-amber-400" />
            <span>Active / Investigating</span>
            <span className="px-1.5 py-0.2 bg-black/30 rounded text-[10px]">{counts.active}</span>
          </button>
          <button
            className={`px-3 py-1.5 text-xs font-semibold rounded flex items-center gap-1.5 transition-colors ${
              tab === "unsolved" ? "bg-purple-600 text-white shadow" : "bg-slate-800 text-purple-300 hover:bg-slate-700"
            }`}
            onClick={() => setTab("unsolved")}
          >
            <CircleAlert size={13} className="text-purple-400" />
            <span>Unsolved / Wanted</span>
            <span className="px-1.5 py-0.2 bg-black/30 rounded text-[10px]">{counts.unsolved}</span>
          </button>
          <button
            className={`px-3 py-1.5 text-xs font-semibold rounded flex items-center gap-1.5 transition-colors ${
              tab === "resolved" ? "bg-emerald-600 text-white shadow" : "bg-slate-800 text-emerald-300 hover:bg-slate-700"
            }`}
            onClick={() => setTab("resolved")}
          >
            <CheckCircle2 size={13} className="text-emerald-400" />
            <span>Solved &amp; Closed</span>
            <span className="px-1.5 py-0.2 bg-black/30 rounded text-[10px]">{counts.resolved}</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Sorting Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-800 border border-slate-700 px-2.5 py-1.5 rounded text-xs text-slate-300">
            <SlidersHorizontal size={13} className="text-blue-400" />
            <span className="text-slate-400 text-[11px]">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              aria-label="Sort cases by"
              className="bg-transparent border-none text-white text-xs outline-none cursor-pointer pr-1"
            >
              <option value="high_alert" className="bg-slate-900 text-white">High Alert First</option>
              <option value="priority" className="bg-slate-900 text-white">Priority (High to Low)</option>
              <option value="recent" className="bg-slate-900 text-white">Latest Activity</option>
              <option value="alpha" className="bg-slate-900 text-white">Subject Alphabetical</option>
            </select>
          </div>

          {/* Quick Search */}
          <div className="relative flex items-center">
            <Search size={14} className="absolute left-2.5 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search cases, suspects, FIRs..."
              className="bg-slate-800 border border-slate-700 pl-8 pr-3 py-1.5 rounded text-xs text-white placeholder-slate-500 outline-none focus:border-blue-500 w-48 sm:w-60"
            />
            {search && (
              <button onClick={() => setSearch("")} className="absolute right-2 text-slate-400 hover:text-white">
                <X size={12} />
              </button>
            )}
          </div>
        </div>
      </section>

      {resolutionMessage ? (
        <div className="resolution-feedback bg-blue-950/40 border border-blue-800/80 p-3 rounded flex items-center gap-2 text-blue-200 text-xs">
          <FileCheck2 size={16} className="text-blue-400 shrink-0" />
          <span>{resolutionMessage}</span>
        </div>
      ) : null}

      {/* Main Two-Column Case Workstation */}
      <section className="case-layout">
        {/* Left Column: Filtered & Sorted Case Register */}
        <article className="command-panel cases-panel">
          <SectionTitle
            eyebrow={`POLICE INTELLIGENCE LEDGER (${filteredCases.length} MATCHES)`}
            title={
              tab === "high_alert"
                ? "State Emergency / High-Alert Register"
                : tab === "resolved"
                ? "Resolved & Closed History"
                : "Active Criminal Case Register"
            }
          />
          <div className="case-register">
            {filteredCases.map((item) => {
              const isSelected = selectedCase?.id === item.id;
              const hasHighAlert = Boolean(item.isHighAlert);
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setSelectedCaseId(item.id);
                    setResolutionMessage("");
                  }}
                  className={`case-row relative transition-all ${isSelected ? "case-row-selected bg-blue-950/30 border-l-4 border-l-blue-500" : "hover:bg-slate-800/40"}`}
                >
                  <div className={`case-row-icon ${item.subjectType}`}>
                    {item.subjectType === "person" ? <UserRoundSearch size={17} /> : <ShieldCheck size={17} />}
                  </div>
                  <div className="case-row-copy">
                    <div className="flex items-center gap-2">
                      <strong>
                        {item.subjectType === "vehicle"
                          ? getPlateDisplay(item.subject, 100).label
                          : getPersonDisplay(item.subject, item.subjectType)}
                      </strong>
                      <PriorityBadge priority={item.priority} />
                      {hasHighAlert && (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-500/20 border border-rose-500/60 text-rose-300 animate-pulse">
                          <Flame size={10} /> HIGH ALERT
                        </span>
                      )}
                      {item.status === "unsolved" && (
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-500/20 border border-purple-500/60 text-purple-300">
                          UNSOLVED
                        </span>
                      )}
                      {item.status === "resolved" && (
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 border border-emerald-500/60 text-emerald-300">
                          SOLVED
                        </span>
                      )}
                    </div>
                    <p>
                      {item.category} · {item.caseReference} {item.incidentDistrict ? `· ${item.incidentDistrict}` : ""}
                    </p>
                    <span className="text-slate-400 text-xs">{item.notes}</span>
                  </div>
                  <ArrowRight className="case-row-arrow" size={16} />
                </button>
              );
            })}
          </div>

          {filteredCases.length === 0 ? (
            <div className="empty-state">
              <Archive size={28} className="text-slate-500" />
              <strong>No cases found in this filter</strong>
              <span>Try adjusting your search criteria or create a new police case above.</span>
            </div>
          ) : null}
        </article>

        {/* Right Column: Case Investigation Detail & Evidence Vault */}
        <aside className="command-panel case-detail-panel">
          {selectedCase ? (
            <>
              {/* High Alert Banner */}
              {selectedCase.isHighAlert && (
                <div className="mb-4 p-3 bg-rose-950/40 border border-rose-600/70 rounded-md flex items-center justify-between gap-3 text-rose-200">
                  <div className="flex items-center gap-2.5">
                    <Flame size={18} className="text-rose-400 animate-bounce" />
                    <div>
                      <strong className="text-xs uppercase tracking-wider block font-bold text-rose-300">
                        CRITICAL HIGH ALERT ACTIVE
                      </strong>
                      <span className="text-[11px] text-rose-200/80">
                        Flagged for immediate intercept across all Gujarat camera perimeters.
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleHighAlert(selectedCase)}
                    className="px-2 py-1 bg-rose-800/60 hover:bg-rose-700 text-[10px] text-white font-semibold rounded border border-rose-500"
                  >
                    De-escalate
                  </button>
                </div>
              )}

              {/* Case Title and Actions */}
              <div className="case-detail-title">
                <div>
                  <p className="eyebrow">
                    {selectedCase.caseReference} · {selectedCase.subjectType.toUpperCase()} INVESTIGATION
                  </p>
                  <h2 className="text-xl font-bold tracking-tight text-white mt-1">
                    {selectedCase.subjectType === "vehicle"
                      ? getPlateDisplay(selectedCase.subject, 100).label
                      : getPersonDisplay(selectedCase.subject, selectedCase.subjectType)}
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {selectedCase.category} · Desk: <strong>{selectedCase.owner}</strong>
                  </p>
                </div>

                <div className="flex flex-col items-end gap-2">
                  <PriorityBadge priority={selectedCase.priority} />
                  <button
                    onClick={() => toggleHighAlert(selectedCase)}
                    className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded border transition-all ${
                      selectedCase.isHighAlert
                        ? "bg-rose-600 hover:bg-rose-500 text-white border-rose-400"
                        : "bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-600"
                    }`}
                  >
                    <Flame size={12} className={selectedCase.isHighAlert ? "text-amber-300" : "text-slate-400"} />
                    <span>{selectedCase.isHighAlert ? "High Alert ON" : "Mark High Alert"}</span>
                  </button>
                </div>
              </div>

              {/* Status and Classification Grid */}
              <div className="case-detail-status">
                <div>
                  <p>CASE STATE</p>
                  <div className="flex items-center gap-2 mt-1">
                    <select
                      value={selectedCase.status}
                      onChange={(e) => handleStatusChange(selectedCase, e.target.value as "active" | "unsolved" | "resolved")}
                      aria-label="Change case status"
                      className="bg-slate-800 border border-slate-600 text-xs text-white rounded px-2 py-1 outline-none cursor-pointer"
                    >
                      <option value="active">Active Investigation</option>
                      <option value="unsolved">Unsolved / Wanted</option>
                      <option value="resolved">Solved &amp; Closed</option>
                    </select>
                  </div>
                </div>
                <div>
                  <p>LAST ACTIVITY</p>
                  <strong>{selectedCase.lastUpdate}</strong>
                </div>
                <div>
                  <p>AUDIT GATE</p>
                  <strong>{selectedCase.status === "active" ? "Evidence Required" : "Audit Signed"}</strong>
                </div>
              </div>

              {/* Case Narrative */}
              {selectedCase.notes && (
                <div className="mb-4 p-3 bg-slate-900/60 border border-slate-700/60 rounded text-xs">
                  <p className="eyebrow mb-1">INVESTIGATION NARRATIVE / INTEL</p>
                  <p className="text-slate-200 leading-relaxed">{selectedCase.notes}</p>
                </div>
              )}

              {/* Evidence Vault & Attached Photos */}
              <div className="case-evidence">
                <div className="flex items-center justify-between mb-2">
                  <p className="eyebrow">ATTACHED EVIDENCE &amp; DETECTIONS ({caseAlerts.length + (selectedCase.evidenceAttachments?.length ?? 0)})</p>
                  <button
                    type="button"
                    onClick={() => setIsAddEvidenceOpen(true)}
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-400 hover:text-blue-300"
                  >
                    <Plus size={13} /> Add Evidence
                  </button>
                </div>

                {/* Evidence Attachments Gallery */}
                {selectedCase.evidenceAttachments && selectedCase.evidenceAttachments.length > 0 && (
                  <div className="space-y-2 mb-3">
                    {selectedCase.evidenceAttachments.map((item) => (
                      <article key={item.id} className="bg-slate-900/70 border border-slate-700/80 p-2.5 rounded flex items-start gap-3">
                        <div className="w-8 h-8 rounded bg-blue-900/40 border border-blue-700/60 flex items-center justify-center text-blue-300 shrink-0">
                          <ImageIcon size={16} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <strong className="text-xs text-white truncate">{item.title}</strong>
                            <span className="text-[10px] text-blue-300 font-mono">{item.reference}</span>
                          </div>
                          <p className="text-[11px] text-slate-300 mt-0.5">{item.summary}</p>
                          <span className="text-[10px] text-slate-500 mt-1 block">Logged {item.timestamp} · Type: {item.type}</span>
                        </div>
                        {item.photoUrl && (
                          <a href={item.photoUrl} target="_blank" rel="noreferrer" className="shrink-0">
                            <img src={item.photoUrl} alt="Evidence" className="w-12 h-12 object-cover rounded border border-slate-600" />
                          </a>
                        )}
                      </article>
                    ))}
                  </div>
                )}

                {/* Correlated CCTV Alerts */}
                {caseAlerts.length > 0 ? (
                  caseAlerts.map((alert) => {
                    const camera = getCamera(alert.cameraId, cameras);
                    return (
                      <article key={alert.id} className="border-t border-slate-800 pt-2 pb-2">
                        <div className="evidence-icon">
                          <Clock3 size={14} />
                        </div>
                        <div>
                          <strong>
                            {alert.timestamp} IST · {camera?.name ?? "Gujarat CCTV"} ·{" "}
                            {alert.subjectType === "vehicle"
                              ? getPlateDisplay(alert.subject, alert.confidence).label
                              : getPersonDisplay(alert.subject, alert.subjectType)}
                          </strong>
                          <p>{alert.summary}</p>
                          <span>{alert.confidence.toFixed(1)}% detection confidence</span>
                        </div>
                        {alert.status === "new" ? (
                          <button
                            onClick={() => acknowledgeMutation.mutate({ id: alert.id })}
                            disabled={acknowledgeMutation.isPending}
                            className="text-xs px-2 py-1 bg-slate-800 rounded border border-slate-600 hover:bg-slate-700"
                          >
                            <Check size={13} /> ACK
                          </button>
                        ) : (
                          <StatusBadge status={alert.status} />
                        )}
                      </article>
                    );
                  })
                ) : !selectedCase.evidenceAttachments?.length ? (
                  <p className="evidence-empty text-xs text-slate-400">No linked CCTV detections in this case file yet.</p>
                ) : null}
              </div>

              {/* Human Verification Protocol */}
              <div className="verification-panel mt-4 p-3 bg-slate-900/50 border border-slate-800 rounded">
                <div>
                  <p className="eyebrow">FORENSIC VERIFICATION / CHAIN OF CUSTODY</p>
                  <strong className="text-xs text-white">
                    {selectedCase.verificationStatus ? `${selectedCase.verificationStatus.replaceAll("_", " ").toUpperCase()}` : "ANALYST APPROVAL PENDING"}
                  </strong>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    {sharedReadOnly
                      ? "Shared observers have read-only view."
                      : "Record evidence review before operational dispatch."}
                  </span>
                </div>

                {!sharedReadOnly && (
                  <div className="alert-action-row mt-2">
                    <button
                      onClick={() => verifyCase("verify")}
                      disabled={verificationMutation.isPending}
                      className="px-2.5 py-1 bg-emerald-950/60 border border-emerald-600 text-emerald-300 text-xs font-semibold rounded hover:bg-emerald-900 flex items-center gap-1"
                    >
                      <Check size={13} /> Approve
                    </button>
                    <button
                      onClick={() => verifyCase("reject")}
                      disabled={verificationMutation.isPending}
                      className="px-2.5 py-1 bg-rose-950/60 border border-rose-600 text-rose-300 text-xs font-semibold rounded hover:bg-rose-900 flex items-center gap-1"
                    >
                      <CircleAlert size={13} /> Reject
                    </button>
                    <button
                      onClick={() => verifyCase("request_more_evidence")}
                      disabled={verificationMutation.isPending}
                      className="px-2.5 py-1 bg-amber-950/60 border border-amber-600 text-amber-300 text-xs font-semibold rounded hover:bg-amber-900"
                    >
                      Request More Evidence
                    </button>
                  </div>
                )}
                {verificationMessage && <small className="text-emerald-400 block mt-1">{verificationMessage}</small>}
              </div>

              {/* Case Resolution Workflow */}
              {selectedCase.status !== "resolved" ? (
                <form className="resolution-form mt-4" onSubmit={submitResolution}>
                  <div className="resolution-form-heading">
                    <div>
                      <p className="eyebrow">EVIDENCE-GATED CASE CLOSURE</p>
                      <h3>Officially Resolve Case</h3>
                    </div>
                    <LockKeyhole size={17} className="text-slate-400" />
                  </div>
                  <p className="resolution-form-intro text-xs text-slate-400">
                    Document verifiable evidence before closing. A resolution cannot be recorded from an uncorroborated assertion.
                  </p>

                  <div className="resolution-form-grid mt-3">
                    <label>
                      Outcome
                      <select
                        value={resolutionForm.outcome}
                        onChange={(e) => setResolutionForm((cur) => ({ ...cur, outcome: e.target.value as ResolutionOutcome }))}
                      >
                        <option value={defaultOutcome(selectedCase.subjectType)}>
                          {outcomeLabel(defaultOutcome(selectedCase.subjectType))}
                        </option>
                        <option value="case_solved">Case Solved / Convicted</option>
                      </select>
                    </label>

                    <label>
                      Evidence Type
                      <select
                        value={resolutionForm.evidenceType}
                        onChange={(e) => setResolutionForm((cur) => ({ ...cur, evidenceType: e.target.value as ResolutionEvidenceType }))}
                      >
                        <option value="cross_camera">Cross-Camera CCTV Correlation</option>
                        <option value="field_confirmation">Field Team Physical Apprehension</option>
                        <option value="official_case_record">Official Court / Forensic Lab Record</option>
                      </select>
                    </label>

                    <label>
                      Evidence Reference Code
                      <input
                        value={resolutionForm.evidenceReference}
                        onChange={(e) => setResolutionForm((cur) => ({ ...cur, evidenceReference: e.target.value }))}
                        placeholder="e.g. PKT-ALT-2041 or FIR-449"
                      />
                    </label>

                    <label>
                      Investigator Evidence Summary
                      <textarea
                        value={resolutionForm.evidenceSummary}
                        onChange={(e) => setResolutionForm((cur) => ({ ...cur, evidenceSummary: e.target.value }))}
                        placeholder="Document verified camera timestamps, intercept coordinates, and officer identification."
                        rows={3}
                      />
                    </label>
                  </div>

                  <button
                    className="resolve-case-button mt-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-4 rounded text-xs uppercase tracking-wider"
                    type="submit"
                    disabled={!resolutionReady}
                  >
                    {resolveMutation.isPending ? "Recording forensic resolution..." : "Officially Record Resolution & Close Case"}
                  </button>
                </form>
              ) : (
                <div className="resolved-note mt-4 p-3 bg-emerald-950/30 border border-emerald-600/60 rounded">
                  <Archive size={17} className="text-emerald-400" />
                  <div>
                    <strong className="text-emerald-300 block text-xs">
                      {selectedCase.resolutionOutcome ? outcomeLabel(selectedCase.resolutionOutcome) : "This case is officially solved and closed"}
                    </strong>
                    <span className="text-slate-300 text-[11px] block mt-0.5">
                      {selectedCase.resolutionEvidenceType
                        ? `${evidenceLabel(selectedCase.resolutionEvidenceType)} · Ref: ${selectedCase.resolutionEvidenceReference}`
                        : "Official forensic resolution recorded."}
                    </span>
                    {selectedCase.resolutionEvidenceSummary && (
                      <p className="text-slate-300 text-xs mt-1 bg-black/20 p-2 rounded">{selectedCase.resolutionEvidenceSummary}</p>
                    )}
                    {selectedCase.resolvedBy && (
                      <small className="text-slate-400 block mt-1">
                        Recorded by {selectedCase.resolvedBy}
                        {selectedCase.resolvedAt ? ` · ${new Date(selectedCase.resolvedAt).toLocaleString()}` : ""}
                      </small>
                    )}
                  </div>
                </div>
              )}
            </>
          ) : null}
        </aside>
      </section>

      {/* CREATE NEW CASE DIALOG */}
      {isAddCaseOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-lg shadow-2xl p-6 text-white max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FilePlus2 className="text-blue-400" size={20} />
                <h3 className="text-base font-bold text-white tracking-wide">Register New Criminal Case / FIR</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddCaseOpen(false)}
                className="text-slate-400 hover:text-white rounded p-1"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateCase} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Case / FIR Reference</label>
                  <input
                    type="text"
                    required
                    value={newCase.caseReference}
                    onChange={(e) => setNewCase({ ...newCase, caseReference: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                    placeholder="e.g. GJ-CRIM-2026-105"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Subject Type</label>
                  <select
                    value={newCase.subjectType}
                    onChange={(e) => setNewCase({ ...newCase, subjectType: e.target.value as SubjectType })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  >
                    <option value="vehicle">Vehicle (Plate Tracked)</option>
                    <option value="person">Person of Interest / Fugitive</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">
                    {newCase.subjectType === "vehicle" ? "License Plate Number" : "Suspect Name"}
                  </label>
                  <input
                    type="text"
                    required
                    value={newCase.subject}
                    onChange={(e) => setNewCase({ ...newCase, subject: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white uppercase outline-none focus:border-blue-500 font-mono font-bold"
                    placeholder={newCase.subjectType === "vehicle" ? "GJ01AB1234" : "Vikas Sharma"}
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Crime Category</label>
                  <input
                    type="text"
                    required
                    value={newCase.category}
                    onChange={(e) => setNewCase({ ...newCase, category: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                    placeholder="e.g. Kidnapping, Armed Robbery, Stolen Vehicle"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Priority</label>
                  <select
                    value={newCase.priority}
                    onChange={(e) => setNewCase({ ...newCase, priority: e.target.value as "high" | "medium" | "low" })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  >
                    <option value="high">High Priority</option>
                    <option value="medium">Medium Priority</option>
                    <option value="low">Low Priority</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Initial Status</label>
                  <select
                    value={newCase.status}
                    onChange={(e) => setNewCase({ ...newCase, status: e.target.value as "active" | "unsolved" | "resolved" })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  >
                    <option value="active">Active Investigation</option>
                    <option value="unsolved">Unsolved / Wanted</option>
                    <option value="resolved">Solved</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">District / Jurisdiction</label>
                  <input
                    type="text"
                    value={newCase.incidentDistrict}
                    onChange={(e) => setNewCase({ ...newCase, incidentDistrict: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                    placeholder="Ahmedabad"
                  />
                </div>
              </div>

              {/* High Alert Toggle Checkbox */}
              <div className="p-3 bg-rose-950/30 border border-rose-600/50 rounded flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Flame size={18} className="text-rose-400" />
                  <div>
                    <span className="text-xs font-bold text-rose-200 block">MARK AS HIGH ALERT / STATE EMERGENCY</span>
                    <span className="text-[11px] text-rose-300/70">Pushes this criminal suspect to the top of police intercept radars.</span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  id="highAlertCheck"
                  checked={newCase.isHighAlert}
                  onChange={(e) => setNewCase({ ...newCase, isHighAlert: e.target.checked })}
                  className="w-4 h-4 accent-rose-600 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Assigned Investigating Officer / Desk</label>
                <input
                  type="text"
                  value={newCase.owner}
                  onChange={(e) => setNewCase({ ...newCase, owner: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  placeholder="e.g. Crime Branch Sector 5"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Case Narrative &amp; Suspect Details</label>
                <textarea
                  value={newCase.notes}
                  onChange={(e) => setNewCase({ ...newCase, notes: e.target.value })}
                  rows={2}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  placeholder="Suspect vehicle seen fleeing southwards on SG Highway. Black SUV with tinted rear windows..."
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Attach Evidence Image URL (Optional)</label>
                <input
                  type="url"
                  value={newCase.evidencePhotoUrl}
                  onChange={(e) => setNewCase({ ...newCase, evidencePhotoUrl: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  placeholder="https://... (or leave blank to use camera frame)"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddCaseOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase rounded shadow-lg"
                >
                  Create &amp; Register Case
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD EVIDENCE DIALOG */}
      {isAddEvidenceOpen && selectedCase && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-lg shadow-2xl p-6 text-white">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ImageIcon className="text-blue-400" size={18} />
                <h3 className="text-base font-bold text-white tracking-wide">
                  Attach Evidence to {selectedCase.caseReference}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddEvidenceOpen(false)}
                className="text-slate-400 hover:text-white rounded p-1"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleAddEvidence} className="space-y-4 mt-4">
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Evidence Title</label>
                <input
                  type="text"
                  required
                  value={newEvidence.title}
                  onChange={(e) => setNewEvidence({ ...newEvidence, title: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  placeholder="e.g. CCTV Toll Junction Frame #4"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Evidence Reference</label>
                  <input
                    type="text"
                    required
                    value={newEvidence.reference}
                    onChange={(e) => setNewEvidence({ ...newEvidence, reference: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white font-mono outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Evidence Type</label>
                  <select
                    value={newEvidence.type}
                    onChange={(e) => setNewEvidence({ ...newEvidence, type: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  >
                    <option value="Cross-Camera ANPR">Cross-Camera ANPR</option>
                    <option value="Live Surveillance Frame">Live Surveillance Frame</option>
                    <option value="Field Dispatch Confirmation">Field Dispatch Confirmation</option>
                    <option value="Forensic Biometric Scan">Forensic Biometric Scan</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Forensic Description / Findings</label>
                <textarea
                  required
                  value={newEvidence.summary}
                  onChange={(e) => setNewEvidence({ ...newEvidence, summary: e.target.value })}
                  rows={3}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  placeholder="Plate matched with 98.4% optical confidence. Driver matched facial telemetry recorded at Paldi..."
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Image URL / Snapshot Link (Optional)</label>
                <input
                  type="url"
                  value={newEvidence.photoUrl}
                  onChange={(e) => setNewEvidence({ ...newEvidence, photoUrl: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  placeholder="https://..."
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddEvidenceOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase rounded shadow-lg"
                >
                  Save Evidence
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
