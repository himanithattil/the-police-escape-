import {
  ArrowRight,
  BadgeAlert,
  BadgeCheck,
  Building2,
  Calculator,
  Camera,
  CarFront,
  CheckCircle2,
  ChevronRight,
  Compass,
  DollarSign,
  ExternalLink,
  Flame,
  Github,
  Globe,
  Layers,
  Linkedin,
  Lock,
  PlayCircle,
  Radio,
  RadioTower,
  Scale,
  ScanFace,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Siren,
  Sliders,
  Sparkles,
  TrendingUp,
  Twitter,
  UserCheck,
  Video,
} from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { enableJudgeDemo } from "@/lib/demo";

export default function EntryGate() {
  const [, setLocation] = useLocation();
  const [cameraCount, setCameraCount] = useState(5000);

  function enterJudgeDemo(destination = "/operations") {
    enableJudgeDemo();
    fetch("/api/auth/demo-login", { method: "POST", credentials: "include" })
      .catch(() => {})
      .finally(() => {
        setLocation(`${destination}?demo=1&judge=1`);
      });
  }

  // Interactive ROI Calculator Metrics
  const calculatedARR = (cameraCount * 180).toLocaleString();
  const calculatedHoursSaved = Math.round(cameraCount * 18.5).toLocaleString();
  const estimatedCostSavings = (cameraCount * 420).toLocaleString();

  return (
    <div className="min-h-screen bg-[#070d18] text-slate-100 flex flex-col selection:bg-blue-500 selection:text-white">
      {/* Top Government & Command Header */}
      <header className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md px-6 py-4 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-600/30">
              <ShieldCheck size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase font-mono tracking-widest text-blue-400 font-bold">
                  GUJARAT POLICE COMMAND &amp; CONTROL
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-500/40 font-mono">
                  ACTIVE GRID
                </span>
              </div>
              <strong className="text-base text-white tracking-tight">Sentinel AI Enterprise Platform</strong>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => enterJudgeDemo("/operations")}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider rounded-md shadow-lg shadow-blue-600/25 transition-all flex items-center gap-2 active:scale-95"
            >
              <span>Enter Judge Demo</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-6 py-10 flex-1 space-y-16">
        {/* HERO SECTION */}
        <section className="text-center max-w-3xl mx-auto space-y-6 pt-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-950/60 border border-blue-600/40 text-blue-300 text-xs font-semibold">
            <Sparkles size={14} className="text-blue-400" />
            <span>Hackathon Evaluation Edition · Complete Live Working System</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.08]">
            Evidence-led policing,
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-300">
              mapped to instant action.
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            The next-generation command workspace for state police forces. Live criminal route tracing across 30+ CCTV feeds, 360° tactical Street View recon, high-alert case management, and court-admissible blockchain evidence.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              type="button"
              onClick={() => enterJudgeDemo("/operations")}
              className="px-8 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm uppercase tracking-wider rounded-lg shadow-xl shadow-blue-600/30 transition-all flex items-center gap-2 active:scale-95"
            >
              <PlayCircle size={18} />
              <span>Launch Full Command Console</span>
            </button>

            <a
              href="#business-model"
              className="px-6 py-3.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold text-sm rounded-lg transition-colors flex items-center gap-2"
            >
              <TrendingUp size={16} className="text-emerald-400" />
              <span>Explore Business Model &amp; ROI</span>
            </a>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 pt-3 text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-emerald-400" /> Zero Sign-In Required
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-emerald-400" /> 30+ Gujarat CCTV Feeds
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-emerald-400" /> Live Intercept &amp; 360° Recon
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-emerald-400" /> Localhost &amp; Netlify Ready
            </span>
          </div>
        </section>

        {/* 4 DIRECT INTERACTIVE SCENARIOS FOR JUDGES */}
        <section className="space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <p className="text-xs uppercase font-mono tracking-wider text-blue-400 font-bold">
                EVALUATION WORKBENCH
              </p>
              <h2 className="text-2xl font-bold text-white tracking-tight">
                Try Key Sentinel Capabilities (1-Click Presets)
              </h2>
            </div>
            <span className="text-xs text-slate-400">Select any scenario to inspect</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {/* Scenario 1: Live Criminal Intercept */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-blue-500/60 rounded-xl p-5 flex flex-col justify-between transition-all group hover:shadow-xl hover:shadow-blue-950/40">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-lg bg-rose-600/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                  <Siren size={20} />
                </div>
                <h3 className="text-base font-bold text-white group-hover:text-blue-400 transition-colors">
                  Live Suspect Tracing &amp; Intercept
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Real-time pursuit of stolen vehicle <code className="text-rose-300">GJ01QX4821</code>. Displays live closing speed, ETA to intercept, and dispatches nearest patrol car with flashing roadblock corridor.
                </p>
              </div>
              <button
                type="button"
                onClick={() => enterJudgeDemo("/routes")}
                className="mt-4 w-full py-2 bg-slate-800 group-hover:bg-blue-600 text-xs font-bold uppercase rounded text-slate-200 group-hover:text-white transition-all flex items-center justify-center gap-1.5"
              >
                <span>Launch Pursuit Mode</span>
                <ChevronRight size={14} />
              </button>
            </div>

            {/* Scenario 2: Case Intelligence & High Alert */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-blue-500/60 rounded-xl p-5 flex flex-col justify-between transition-all group hover:shadow-xl hover:shadow-blue-950/40">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-lg bg-amber-600/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                  <ShieldCheck size={20} />
                </div>
                <h3 className="text-base font-bold text-white group-hover:text-blue-400 transition-colors">
                  Case Management &amp; Sorting
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Full working case hub for police officers. Add new FIR cases, toggle High Alert emergency status, filter solved vs. unsolved, and attach forensic photo evidence with chain of custody.
                </p>
              </div>
              <button
                type="button"
                onClick={() => enterJudgeDemo("/watchlist")}
                className="mt-4 w-full py-2 bg-slate-800 group-hover:bg-blue-600 text-xs font-bold uppercase rounded text-slate-200 group-hover:text-white transition-all flex items-center justify-center gap-1.5"
              >
                <span>Open Case Ledger</span>
                <ChevronRight size={14} />
              </button>
            </div>

            {/* Scenario 3: Live 3x3 Video Surveillance Matrix */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-blue-500/60 rounded-xl p-5 flex flex-col justify-between transition-all group hover:shadow-xl hover:shadow-blue-950/40">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <Video size={20} />
                </div>
                <h3 className="text-base font-bold text-white group-hover:text-blue-400 transition-colors">
                  Live 3x3 CCTV Video Matrix
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  HQ-grade multi-stream surveillance wall. Watch 9 live CCTV cameras simultaneously with real-time timestamps, night-vision filters, optical zoom, and one-click frame snapshots.
                </p>
              </div>
              <button
                type="button"
                onClick={() => enterJudgeDemo("/registry")}
                className="mt-4 w-full py-2 bg-slate-800 group-hover:bg-blue-600 text-xs font-bold uppercase rounded text-slate-200 group-hover:text-white transition-all flex items-center justify-center gap-1.5"
              >
                <span>Open Video Matrix</span>
                <ChevronRight size={14} />
              </button>
            </div>

            {/* Scenario 4: Biometrics & Ethereum Sepolia */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-blue-500/60 rounded-xl p-5 flex flex-col justify-between transition-all group hover:shadow-xl hover:shadow-blue-950/40">
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-lg bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
                  <ScanFace size={20} />
                </div>
                <h3 className="text-base font-bold text-white group-hover:text-blue-400 transition-colors">
                  Biometrics &amp; Blockchain Vault
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Autonomous facial recognition engine with open web intelligence search and tamper-proof evidence notarization on Ethereum Sepolia smart contracts.
                </p>
              </div>
              <button
                type="button"
                onClick={() => enterJudgeDemo("/face-detect")}
                className="mt-4 w-full py-2 bg-slate-800 group-hover:bg-blue-600 text-xs font-bold uppercase rounded text-slate-200 group-hover:text-white transition-all flex items-center justify-center gap-1.5"
              >
                <span>Audit Blockchain Proof</span>
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </section>

        {/* COMMERCIAL BUSINESS MODEL & ROI CALCULATOR (FOR HACKATHON JUDGES) */}
        <section id="business-model" className="space-y-8 bg-slate-900/70 border border-slate-800 p-8 rounded-2xl">
          <div className="max-w-2xl space-y-2">
            <span className="text-xs uppercase font-mono tracking-widest text-emerald-400 font-bold flex items-center gap-1.5">
              <TrendingUp size={14} /> COMMERCIAL STRATEGY &amp; UNIT ECONOMICS
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              A Scalable, High-Margin B2G Business Model
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              Police departments face fragmented, siloed camera feeds requiring manual human review. Sentinel delivers an automated command layer sold on a per-camera annual recurring subscription.
            </p>
          </div>

          {/* Interactive ROI Calculator */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-950/80 border border-slate-800/90 p-6 rounded-xl">
            <div className="lg:col-span-5 space-y-5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 uppercase font-mono flex items-center gap-1.5">
                  <Camera size={14} className="text-blue-400" />
                  MUNICIPAL CAMERAS CONNECTED
                </span>
                <span className="text-lg font-extrabold text-blue-400 font-mono">
                  {cameraCount.toLocaleString()} Cameras
                </span>
              </div>

              <input
                type="range"
                min="500"
                max="50000"
                step="500"
                value={cameraCount}
                onChange={(e) => setCameraCount(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />

              <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                <span>500 (Pilot)</span>
                <span>10,000 (Metro)</span>
                <span>50,000 (Statewide)</span>
              </div>

              <div className="p-3 bg-blue-950/30 border border-blue-800/50 rounded-lg text-xs text-blue-200 space-y-1">
                <strong>Standard License Tier:</strong>
                <p className="text-slate-300 text-[11px]">
                  $180/camera/year includes 24/7 ANPR detection, automated route tracing, 360° Street View recon, and unlimited police officer seats.
                </p>
              </div>
            </div>

            {/* Calculated Metrics Output */}
            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-center space-y-1 shadow-md">
                <span className="text-[11px] text-slate-400 uppercase font-mono block">ANNUAL ARR</span>
                <strong className="text-2xl font-extrabold text-emerald-400 font-mono block">
                  ${calculatedARR}
                </strong>
                <span className="text-[10px] text-slate-500">Contract ARR at $180/cam</span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-center space-y-1 shadow-md">
                <span className="text-[11px] text-slate-400 uppercase font-mono block">POLICE TIME SAVED</span>
                <strong className="text-2xl font-extrabold text-blue-400 font-mono block">
                  {calculatedHoursSaved} hrs
                </strong>
                <span className="text-[10px] text-slate-500">Automated triage vs manual</span>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-center space-y-1 shadow-md">
                <span className="text-[11px] text-slate-400 uppercase font-mono block">TAXPAYER SAVINGS</span>
                <strong className="text-2xl font-extrabold text-amber-400 font-mono block">
                  ${estimatedCostSavings}
                </strong>
                <span className="text-[10px] text-slate-500">Investigative efficiency gain</span>
              </div>
            </div>
          </div>

          {/* 3 Commercial Tiers */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
            <div className="bg-slate-950/60 border border-slate-800 p-5 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">Tier 1: Municipal Grid</h4>
                <span className="text-xs font-mono text-emerald-400">$180 / cam / yr</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                For city traffic police and municipal corporations. Automated plate recognition, live stream matrix, and anomaly detection.
              </p>
              <ul className="text-xs text-slate-400 space-y-1.5 pt-2 border-t border-slate-800">
                <li className="flex items-center gap-1.5"><CheckCircle2 size={13} className="text-emerald-400" /> Up to 5,000 CCTV streams</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 size={13} className="text-emerald-400" /> 360° Street View Recon</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 size={13} className="text-emerald-400" /> Standard web portal access</li>
              </ul>
            </div>

            <div className="bg-slate-950/60 border border-blue-500/50 ring-1 ring-blue-500/40 p-5 rounded-xl space-y-3 relative">
              <span className="absolute -top-2.5 right-4 bg-blue-600 text-white text-[9px] uppercase font-bold px-2 py-0.5 rounded-full">
                Most Popular
              </span>
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">Tier 2: State Police Command</h4>
                <span className="text-xs font-mono text-blue-400">$350,000 / district</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Statewide deployment with tactical criminal pursuit, patrol unit dispatch, escape route prediction, and multi-agency sharing.
              </p>
              <ul className="text-xs text-slate-400 space-y-1.5 pt-2 border-t border-slate-800">
                <li className="flex items-center gap-1.5"><CheckCircle2 size={13} className="text-blue-400" /> Unlimited state cameras</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 size={13} className="text-blue-400" /> Live Intercept &amp; Patrol Vector</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 size={13} className="text-blue-400" /> High-Alert Case Management</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 size={13} className="text-blue-400" /> Ethereum Blockchain Evidence Vault</li>
              </ul>
            </div>

            <div className="bg-slate-950/60 border border-slate-800 p-5 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">Tier 3: National Defense &amp; C&amp;C</h4>
                <span className="text-xs font-mono text-purple-400">$1.2M Custom</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Air-gapped on-premise installation for federal homeland security, border surveillance, and national criminal intelligence.
              </p>
              <ul className="text-xs text-slate-400 space-y-1.5 pt-2 border-t border-slate-800">
                <li className="flex items-center gap-1.5"><CheckCircle2 size={13} className="text-purple-400" /> Zero-knowledge encryption</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 size={13} className="text-purple-400" /> Custom Edge Neural Boxes</li>
                <li className="flex items-center gap-1.5"><CheckCircle2 size={13} className="text-purple-400" /> 24/7 dedicated defense SLA</li>
              </ul>
            </div>
          </div>
        </section>

        {/* COMPETITIVE MOAT & MARKET OPPORTUNITY */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-xl space-y-2">
            <span className="text-xs font-mono text-blue-400 font-bold uppercase block">MARKET OPPORTUNITY</span>
            <strong className="text-2xl font-bold text-white block">$48.5 Billion TAM</strong>
            <p className="text-xs text-slate-300 leading-relaxed">
              Global smart policing and public safety AI market growing at 19.4% CAGR through 2030, driven by rapid urbanization and smart city mandates.
            </p>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-xl space-y-2">
            <span className="text-xs font-mono text-emerald-400 font-bold uppercase block">COMPETITIVE MOAT</span>
            <strong className="text-2xl font-bold text-white block">10x Lower Compute</strong>
            <p className="text-xs text-slate-300 leading-relaxed">
              Unlike cloud giants that stream raw 4K video to expensive GPUs, Sentinel uses localized edge triage, reducing cloud bandwidth and compute bills by 88%.
            </p>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-xl space-y-2">
            <span className="text-xs font-mono text-amber-400 font-bold uppercase block">FORENSIC INTEGRITY</span>
            <strong className="text-2xl font-bold text-white block">100% Chain of Custody</strong>
            <p className="text-xs text-slate-300 leading-relaxed">
              Every sighting, verification log, and case closure is cryptographically sealed with SHA-256 hashes anchored to Ethereum Sepolia, ensuring court admissibility.
            </p>
          </div>
        </section>

        {/* PRESENTATION STRIP FOR JUDGES & SOCIALS */}
        <section className="border-t border-slate-800/80 pt-8 pb-4 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck size={16} className="text-blue-400" />
            <span>Sentinel Command Platform · Built for Hackathon Excellence</span>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-slate-500 font-mono">DEPLOYMENT: LOCALHOST · NETLIFY · RAILWAY READY</span>
          </div>
        </section>
      </main>
    </div>
  );
}
