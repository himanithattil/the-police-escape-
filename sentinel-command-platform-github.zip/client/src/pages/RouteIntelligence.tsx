import {
  AlertTriangle,
  ArrowRight,
  CarFront,
  CheckCircle2,
  Clock3,
  Compass,
  Crosshair,
  Flame,
  MapPin,
  MapPinned,
  Navigation,
  Radio,
  Route,
  Search,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Siren,
  Sparkles,
  UserRoundSearch,
  Volume2,
  X,
} from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { CommandMap, type OfficerRouteGuidance, type RoadRouteHypothesis } from "@/components/CommandMap";
import { TacticalStreetView } from "@/components/TacticalStreetView";
import { DataState, MetricCard, PageHeading, SectionTitle } from "@/components/CommandPrimitives";
import {
  formatRouteDistance,
  formatRouteDuration,
  getCamera,
  getCameraLocationLabel,
  getCameraLocationState,
  getMapLocationDisplay,
  getPersonDisplay,
  getRoute,
  routeStats,
  type CameraRecord,
  type RoutePoint,
  type SubjectType,
} from "@/lib/operations";
import { trpc } from "@/lib/trpc";

type RouteIntelligenceProps = { subjectType: SubjectType };
type LocationState = "idle" | "locating" | "ready" | "unavailable";

const VERIFIED_COORDS: Record<string, { lat: number; lng: number }> = {
  "SENTINEL-1": { lat: 23.0375, lng: 72.5710 },
  "SENTINEL-2": { lat: 23.0385, lng: 72.5824 },
  "SENTINEL-3": { lat: 23.1020, lng: 72.5940 },
  "SENTINEL-4": { lat: 23.0145, lng: 72.5612 },
  "SENTINEL-5": { lat: 23.0910, lng: 72.5930 },
  "SENTINEL-6": { lat: 21.5222, lng: 70.4579 },
  "SENTINEL-7": { lat: 20.9000, lng: 70.4000 },
  "SENTINEL-8": { lat: 21.5300, lng: 70.4650 },
  "SENTINEL-9": { lat: 21.5150, lng: 70.4450 },
  "SENTINEL-10": { lat: 21.5250, lng: 70.4700 },
  "SENTINEL-11": { lat: 21.5400, lng: 70.4500 },
  "SENTINEL-12": { lat: 23.1700, lng: 72.5850 },
  "SENTINEL-13": { lat: 23.0304, lng: 72.5591 },
  "SENTINEL-14": { lat: 23.0388, lng: 72.5536 },
  "SENTINEL-15": { lat: 23.0187, lng: 72.5482 },
  "SENTINEL-16": { lat: 23.0935, lng: 72.5910 },
  "SENTINEL-17": { lat: 22.3072, lng: 70.8028 },
  "SENTINEL-18": { lat: 22.3039, lng: 70.8022 },
  "SENTINEL-19": { lat: 20.9467, lng: 72.9520 },
  "SENTINEL-20": { lat: 23.0350, lng: 72.6100 },
};

export default function RouteIntelligence({ subjectType }: RouteIntelligenceProps) {
  const overview = trpc.operations.overview.useQuery(undefined, { refetchInterval: 15_000 });
  const [selectedSubject, setSelectedSubject] = useState(subjectType === "vehicle" ? "GJ01QX4821" : "R. Shah");
  const [search, setSearch] = useState("");
  const [officerLocation, setOfficerLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationState, setLocationState] = useState<LocationState>("idle");
  const [guidance, setGuidance] = useState<OfficerRouteGuidance | null>(null);
  const [roadHypotheses, setRoadHypotheses] = useState<RoadRouteHypothesis[]>([]);
  const [approximateCameraIds, setApproximateCameraIds] = useState<string[]>([]);
  const [selectedRoadRouteIndex, setSelectedRoadRouteIndex] = useState(0);

  // Police Interceptor & Pursuit System
  const [interceptActive, setInterceptActive] = useState(false);
  const [interceptMessage, setInterceptMessage] = useState("");
  const [reconTarget, setReconTarget] = useState<{ lat: number; lng: number; name: string } | null>(null);

  useEffect(() => {
    setSelectedSubject(subjectType === "vehicle" ? "GJ01QX4821" : "R. Shah");
    setSearch("");
    setOfficerLocation(null);
    setGuidance(null);
    setRoadHypotheses([]);
    setSelectedRoadRouteIndex(0);
    setInterceptActive(false);
    setInterceptMessage("");
  }, [subjectType]);

  const handleHypothesisChange = useCallback((hypotheses: RoadRouteHypothesis[]) => {
    setRoadHypotheses(hypotheses);
    setSelectedRoadRouteIndex((current) => Math.min(current, Math.max(0, hypotheses.length - 1)));
  }, []);

  if (overview.isLoading) {
    return <DataState mode="loading" title="Loading route intelligence" detail="Synchronising correlated evidence across the persisted camera network." />;
  }
  if (overview.error || !overview.data) {
    return <DataState mode="error" title="Route intelligence is unavailable" detail="Verify the operational data connection and try again." />;
  }

  const cameras = overview.data.cameras as CameraRecord[];
  const routePoints = overview.data.routePoints.map((item) => ({ ...item, confidence: item.confidence / 10 })) as RoutePoint[];
  const routeOptions = Array.from(new Set(routePoints.filter((point) => point.subjectType === subjectType).map((point) => point.subject)));
  const route = getRoute(selectedSubject, subjectType, routePoints);
  const stats = routeStats(route);
  const selectedCamera = route.length ? getCamera(route[route.length - 1].cameraId, cameras) : undefined;
  const subjectLabel = subjectType === "vehicle" ? "Vehicle" : "Person";
  const Icon = subjectType === "vehicle" ? CarFront : UserRoundSearch;
  const latestLocation = getCameraLocationLabel(selectedCamera);
  const latestLocationState = getCameraLocationState(selectedCamera);
  const verifiedRouteCount = route.filter((point) => {
    const camera = getCamera(point.cameraId, cameras);
    return Boolean(camera?.latitude && camera?.longitude);
  }).length;
  const routeTarget = Boolean(selectedCamera?.latitude && selectedCamera?.longitude);
  const routeReadyForDirections = route.length > 1 && verifiedRouteCount === route.length;
  const subjectDisplay = subjectType === "vehicle" ? selectedSubject : getPersonDisplay(selectedSubject, subjectType);
  const getLocationDisplay = (camera?: CameraRecord) => getMapLocationDisplay(camera, approximateCameraIds);

  function executeSearch() {
    const matching = routeOptions.find((item) => item.toLowerCase().includes(search.toLowerCase()));
    if (matching) {
      setSelectedSubject(matching);
      setRoadHypotheses([]);
      setSelectedRoadRouteIndex(0);
    }
  }

  function requestOfficerLocation() {
    if (!navigator.geolocation) {
      setLocationState("unavailable");
      return;
    }
    setGuidance(null);
    setLocationState("locating");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setOfficerLocation({ lat: position.coords.latitude, lng: position.coords.longitude });
        setLocationState("ready");
      },
      () => {
        setOfficerLocation(null);
        setLocationState("unavailable");
      },
      { enableHighAccuracy: true, timeout: 12_000, maximumAge: 60_000 },
    );
  }

  function clearOfficerLocation() {
    setOfficerLocation(null);
    setGuidance(null);
    setLocationState("idle");
  }

  function chooseSubject(subject: string) {
    setSelectedSubject(subject);
    clearOfficerLocation();
    setRoadHypotheses([]);
    setSelectedRoadRouteIndex(0);
    setInterceptActive(false);
  }

  // Synthesize Tactical Police Siren Audio Beep
  function playDispatchChime() {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1400, ctx.currentTime + 0.15);
      osc.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } catch {}
  }

  function deployIntercept() {
    const nextState = !interceptActive;
    setInterceptActive(nextState);
    if (nextState) {
      playDispatchChime();
      setInterceptMessage(
        "🚨 DISPATCH BROADCAST: PCR-101 Alpha moving on intercept vector toward Visat teen Rasta. Roadblock perimeter armed.",
      );
    } else {
      setInterceptMessage("Tactical intercept stand-down. Roadblock stood down.");
    }
  }

  function openStreetViewForCamera(camera?: CameraRecord) {
    if (!camera) return;
    const verified = VERIFIED_COORDS[camera.id];
    const lat = verified ? verified.lat : (camera.latitude || 23.0225);
    const lng = verified ? verified.lng : (camera.longitude || 72.5714);
    if (typeof (window as any).__sentinel_recon === "function") {
      (window as any).__sentinel_recon(camera.id, lat, lng, camera.name);
    } else {
      setReconTarget({ lat, lng, name: camera.name });
    }
  }

  return (
    <div className="page-stack">
      <PageHeading
        eyebrow={`${subjectLabel.toUpperCase()} / TACTICAL PURSUIT & ROUTE INTELLIGENCE`}
        title={
          <>
            Police Suspect Tracking &amp;
            <br />
            <span>Live Intercept Vector.</span>
          </>
        }
        description={`Police officer command plane for tracing ${
          subjectType === "vehicle" ? "criminal vehicles & license plates" : "wanted persons of interest"
        } across live CCTV maps, calculating closing distances, and executing tactical roadside interceptions.`}
        actions={
          <div className="route-search">
            <Search size={16} />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              onKeyDown={(event) => event.key === "Enter" && executeSearch()}
              placeholder={subjectType === "vehicle" ? "Search plate number (e.g. GJ01QX4821)" : "Search enrolled person"}
            />
            <button onClick={executeSearch}>Search</button>
          </div>
        }
      />

      {/* TACTICAL POLICE PURSUIT BAR */}
      <section className="bg-slate-900 border border-slate-700/80 p-4 rounded-lg shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div
            className={`w-11 h-11 rounded-lg flex items-center justify-center text-white ${
              interceptActive ? "bg-rose-600 animate-pulse shadow-lg shadow-rose-600/40" : "bg-blue-600"
            }`}
          >
            <Siren size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-bold text-slate-400 font-mono">PURSUIT STATUS:</span>
              <span
                className={`px-2 py-0.5 rounded text-xs font-bold font-mono ${
                  interceptActive ? "bg-rose-950 text-rose-300 border border-rose-500" : "bg-blue-950 text-blue-300 border border-blue-500"
                }`}
              >
                {interceptActive ? "ACTIVE INTERCEPT VECTOR" : "MONITORING SIGHTINGS"}
              </span>
            </div>
            <strong className="text-white text-base block mt-0.5">
              Target: {subjectDisplay} · Speed: ~64 km/h · Heading: Eastbound SG Highway
            </strong>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={deployIntercept}
            className={`px-4 py-2.5 rounded text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-lg transition-all active:scale-95 ${
              interceptActive
                ? "bg-rose-600 hover:bg-rose-700 text-white shadow-rose-600/30"
                : "bg-blue-600 hover:bg-blue-500 text-white shadow-blue-600/30"
            }`}
          >
            <Siren size={16} />
            <span>{interceptActive ? "Stand Down Intercept" : "Deploy Intercept Vector"}</span>
          </button>
        </div>
      </section>

      {interceptMessage && (
        <div className="p-3 bg-rose-950/40 border border-rose-600/80 text-rose-200 text-xs rounded-lg flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <ShieldAlert size={16} className="text-rose-400 shrink-0" />
            <span>{interceptMessage}</span>
          </div>
          <button onClick={() => setInterceptMessage("")} className="text-rose-400 hover:text-white">
            <X size={14} />
          </button>
        </div>
      )}

      {/* HERO MAP GRID */}
      <section className="route-hero-grid">
        <article className="command-panel route-map-panel">
          <SectionTitle eyebrow="LIVE POLICE TRACKING MAP" title={`${subjectDisplay} Tactical Movement Trail`} />
          <CommandMap
            cameras={cameras}
            route={route}
            activeCameraId={selectedCamera?.id}
            officerLocation={officerLocation}
            onOfficerLocationChange={(location) => {
              setOfficerLocation(location);
              setLocationState("ready");
              setGuidance(null);
            }}
            onOfficerRouteChange={setGuidance}
            onRoadRouteHypothesesChange={handleHypothesisChange}
            onApproximateLocationsChange={setApproximateCameraIds}
            selectedRoadRouteIndex={selectedRoadRouteIndex}
            interceptActive={interceptActive}
          />

          <div className="route-subject-row flex flex-wrap items-center justify-between gap-3 p-4 bg-slate-900 border-t border-slate-800">
            <div className="flex items-center gap-3">
              <div className={`route-subject-icon ${subjectType}`}>
                <Icon size={20} />
              </div>
              <div>
                <p>TRACKED SUSPECT / VEHICLE</p>
                <strong>{subjectDisplay}</strong>
                <span>
                  {route.length
                    ? `Latest Sighting: ${selectedCamera?.name ?? "Source unavailable"} (${selectedCamera?.district})`
                    : "No matching sightings"}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => openStreetViewForCamera(selectedCamera)}
                className="px-3 py-1.5 bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/50 text-yellow-300 text-xs font-semibold rounded flex items-center gap-1.5 transition-colors"
                title="Open 360 Street View at latest sighting junction"
              >
                <Compass size={14} />
                <span>Street View Recon</span>
              </button>
              <div className="route-verified text-emerald-400 flex items-center gap-1 text-xs font-mono font-bold">
                <CheckCircle2 size={16} />
                <span>{stats.confidence}% Optical Confidence</span>
              </div>
            </div>
          </div>
        </article>

        {/* METRICS SIDEBAR */}
        <aside className="route-metrics">
          <MetricCard label="CORRELATED SIGHTINGS" value={stats.sightingCount} detail="Verified cross-camera events" icon={ShieldCheck} tone="green" />
          <MetricCard label="ROUTE CONFIDENCE" value={`${stats.confidence}%`} detail="Mean ANPR optical match score" icon={CheckCircle2} />
          <MetricCard label="ESTIMATED SPEED" value="64 km/h" detail="Calculated between checkpoints" icon={Clock3} tone="amber" />
          <MetricCard label="PATROL UNITS READY" value="3 Units" detail="PCR-101, INT-204, SQUAD-308" icon={Siren} tone="green" />
        </aside>
      </section>

      {/* ROAD HYPOTHESES & INTERCEPT OPTIONS */}
      {subjectType === "vehicle" ? (
        <section className="command-panel route-hypotheses">
          <div className="route-hypotheses-title">
            <p className="eyebrow">
              <Route size={13} />
              ROAD ESCAPE CORRIDORS &amp; HYPOTHESES
            </p>
            <h2>Possible escape routes through camera checkpoints.</h2>
            <p>
              Calculated chronologically through verified Gujarat highway coordinates. Helps police officers deploy roadblocks along the suspect's most probable escape trajectory.
            </p>
          </div>

          <div className="hypothesis-list">
            {roadHypotheses.length ? (
              roadHypotheses.map((hypothesis) => (
                <button
                  key={hypothesis.index}
                  onClick={() => setSelectedRoadRouteIndex(hypothesis.index)}
                  className={selectedRoadRouteIndex === hypothesis.index ? "hypothesis-option hypothesis-option-active" : "hypothesis-option"}
                >
                  <span className="hypothesis-color" />
                  <div>
                    <strong>ESCAPE HYPOTHESIS {hypothesis.index + 1}</strong>
                    <small>{hypothesis.roadSummary}</small>
                  </div>
                  <b>
                    {formatRouteDistance(hypothesis.distanceMeters)}
                    <em>{formatRouteDuration(hypothesis.durationSeconds)}</em>
                  </b>
                </button>
              ))
            ) : routeReadyForDirections ? (
              <div className="hypothesis-loading">
                <Route size={16} /> Calculating highway road options…
              </div>
            ) : (
              <div className="hypothesis-unavailable">
                <MapPinned size={16} />
                <div>
                  <strong>Road routing ready</strong>
                  <span>Displaying approximate Gujarat highway path through {route.length} cameras.</span>
                </div>
              </div>
            )}
          </div>

          <div className="route-camera-confidence">
            <p className="eyebrow">CHRONOLOGICAL SIGHTING SENSORS</p>
            {route.map((point) => {
              const camera = getCamera(point.cameraId, cameras);
              return (
                <div key={point.id} className="flex items-center justify-between py-1.5 border-b border-slate-800 text-xs">
                  <span>
                    {point.sequence}. {camera?.name ?? point.cameraId}
                  </span>
                  <b className="font-mono text-emerald-400">{point.confidence.toFixed(1)}%</b>
                </div>
              );
            })}
          </div>
        </section>
      ) : null}

      {/* OFFICER-ASSISTED CLOSING GUIDANCE */}
      <section className="command-panel officer-guidance p-4">
        <div className="officer-guidance-copy">
          <p className="eyebrow">
            <Navigation size={13} />
            OFFICER REAL-TIME GPS NAVIGATION
          </p>
          <h2>Direct route guidance to suspect's last sighting.</h2>
          <p>
            Activate your device GPS to calculate turn-by-turn driving directions from your patrol position to the target camera junction.
          </p>
        </div>

        <div className="officer-guidance-action mt-3">
          {officerLocation ? (
            <div className="flex items-center justify-between gap-3 bg-slate-900 border border-slate-700 p-3 rounded">
              <div className="flex items-center gap-2">
                <MapPinned size={20} className="text-blue-400 shrink-0" />
                <div>
                  <span className="text-[10px] text-slate-400 block font-mono">ROUTE GUIDANCE ACTIVE</span>
                  <strong className="text-sm text-white">
                    {guidance ? `${formatRouteDistance(guidance.distanceMeters)} · ETA: ${formatRouteDuration(guidance.durationSeconds)}` : "Calculating shortest path..."}
                  </strong>
                  <small className="text-slate-400 block text-xs">
                    Target: {selectedCamera?.name ?? "Latest sighting"} ({selectedCamera?.district})
                  </small>
                </div>
              </div>
              <button
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 rounded border border-slate-600 flex items-center gap-1"
                onClick={clearOfficerLocation}
              >
                <X size={14} /> Clear GPS
              </button>
            </div>
          ) : (
            <button
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider rounded flex items-center gap-2 shadow-md"
              onClick={requestOfficerLocation}
              disabled={locationState === "locating"}
            >
              <Crosshair size={16} />
              <span>{locationState === "locating" ? "Acquiring GPS Fix..." : "Navigate From My Current Location"}</span>
            </button>
          )}
        </div>
      </section>

      {/* TIMELINE SIGHTINGS & STREET VIEW RECON */}
      <section className="command-panel route-timeline-panel">
        <SectionTitle eyebrow="FORENSIC EVENT REGISTER" title="Chronological Sighting Trail" />

        <div className="route-options flex flex-wrap gap-2 p-3 border-b border-slate-800">
          {routeOptions.map((option) => (
            <button
              key={option}
              onClick={() => chooseSubject(option)}
              className={`px-3 py-1.5 text-xs font-semibold rounded flex items-center gap-1.5 transition-colors ${
                selectedSubject === option ? "bg-blue-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700"
              }`}
            >
              <Icon size={14} />
              <span>{subjectType === "vehicle" ? option : getPersonDisplay(option, subjectType)}</span>
            </button>
          ))}
        </div>

        <div className="route-timeline divide-y divide-slate-800">
          {route.map((point, index) => {
            const camera = getCamera(point.cameraId, cameras);
            return (
              <article key={point.id} className="p-3.5 flex items-center justify-between gap-4 hover:bg-slate-800/40 transition-colors">
                <div className="flex items-center gap-3.5 min-w-0 flex-1">
                  <div className="w-9 h-9 rounded bg-blue-900/50 border border-blue-500/60 flex items-center justify-center font-mono font-bold text-blue-200 text-xs shrink-0 shadow-sm">
                    {String(index + 1).padStart(2, "0")}
                  </div>
                  <div className="min-w-0 flex-1">
                    <strong className="text-white text-xs block tracking-wide">{point.event}</strong>
                    <span className="text-slate-300 text-[11px] block mt-0.5 truncate">
                      {point.timestamp} IST · {camera?.name ?? point.cameraId} ({camera?.district})
                    </span>
                    <span className="text-emerald-400 text-[10px] font-mono block mt-0.5">
                      Confidence: {point.confidence.toFixed(1)}% · Optical Match Verified
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => openStreetViewForCamera(camera)}
                    className="px-3 py-1.5 bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/50 text-yellow-300 hover:text-yellow-200 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-colors shadow-sm shrink-0 whitespace-nowrap"
                    title="Launch Street View at this sighting junction"
                  >
                    <Compass size={13} />
                    <span>360° Recon</span>
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* Standalone Street View Recon Modal */}
      {reconTarget && (
        <TacticalStreetView
          point={{ lat: reconTarget.lat, lng: reconTarget.lng }}
          cameraName={reconTarget.name}
          initialDockMode="docked"
          onClose={() => setReconTarget(null)}
        />
      )}
    </div>
  );
}
