import {
  Camera,
  CheckCircle2,
  Download,
  Eye,
  FileSpreadsheet,
  Filter,
  Grid,
  Layers,
  List,
  MapPin,
  Maximize2,
  Plus,
  Radio,
  RadioTower,
  RefreshCw,
  Search,
  ShieldAlert,
  SlidersHorizontal,
  Upload,
  Video,
  X,
} from "lucide-react";
import { FormEvent, useMemo, useState } from "react";
import { CommandMap } from "@/components/CommandMap";
import { LiveCCTVPlayer } from "@/components/LiveCCTVPlayer";
import { DataState, MetricCard, PageHeading, SectionTitle, StatusBadge } from "@/components/CommandPrimitives";
import {
  getCameraTelemetry,
  getDashboardMetrics,
  mergeCamerasWithStorage,
  saveCustomCamera,
  type AlertRecord,
  type CameraRecord,
  type CameraStatus,
} from "@/lib/operations";
import { trpc } from "@/lib/trpc";
import { isJudgeDemo } from "@/lib/demo";

const filters: Array<CameraStatus | "all"> = ["all", "online", "degraded", "maintenance", "offline"];

export default function CameraRegistry() {
  const [filter, setFilter] = useState<CameraStatus | "all">("all");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState("SENTINEL-1");
  const [viewMode, setViewMode] = useState<"detail" | "matrix">("detail");
  const [localUpdateNonce, setLocalUpdateNonce] = useState(0);
  const [feedback, setFeedback] = useState("");

  // Add Camera Modal State
  const [isAddCameraOpen, setIsAddCameraOpen] = useState(false);
  const [newCam, setNewCam] = useState({
    id: `SENTINEL-${Math.floor(31 + Math.random() * 50)}`,
    name: "",
    district: "Ahmedabad North",
    department: "Gujarat Police Sentinel Sandbox",
    status: "online" as CameraStatus,
    source: "RTSP · H.265",
    latitude: 23.0225,
    longitude: 72.5714,
    coordinateAccuracyMeters: 15,
    streamUrl: "",
    streamType: "simulated" as "simulated" | "mp4" | "hls" | "rtsp",
  });

  // Batch Upload Modal State
  const [isBatchOpen, setIsBatchOpen] = useState(false);
  const [csvContent, setCsvContent] = useState("");

  const judgeDemo = isJudgeDemo();
  const overview = trpc.operations.overview.useQuery(undefined, { refetchInterval: 15_000 });

  const rawCameras = useMemo(() => {
    const fromApi = (overview.data?.cameras ?? []) as CameraRecord[];
    return mergeCamerasWithStorage(fromApi);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [overview.data?.cameras, localUpdateNonce]);

  const alerts = useMemo(() => {
    return (overview.data?.alerts ?? []).map((item) => ({ ...item, confidence: item.confidence / 10 })) as AlertRecord[];
  }, [overview.data?.alerts]);

  const metrics = useMemo(() => getDashboardMetrics(rawCameras, alerts), [rawCameras, alerts]);

  const healthCounts = useMemo(
    () => ({
      online: rawCameras.filter((c) => c.status === "online").length,
      degraded: rawCameras.filter((c) => c.status === "degraded").length,
      offline: rawCameras.filter((c) => c.status === "offline").length,
    }),
    [rawCameras],
  );

  const visible = useMemo(
    () =>
      rawCameras.filter(
        (camera) =>
          (filter === "all" || camera.status === filter) &&
          `${camera.name} ${camera.id} ${camera.district} ${camera.source}`.toLowerCase().includes(search.toLowerCase()),
      ),
    [rawCameras, filter, search],
  );

  const selectedCamera = useMemo(() => {
    return rawCameras.find((item) => item.id === selected) ?? rawCameras[0];
  }, [rawCameras, selected]);

  const selectedTelemetry = selectedCamera ? getCameraTelemetry(selectedCamera) : null;

  function handleCreateCamera(e: FormEvent) {
    e.preventDefault();
    if (!newCam.name.trim()) {
      alert("Please provide a camera name.");
      return;
    }

    const record: CameraRecord = {
      id: newCam.id.trim(),
      name: newCam.name.trim(),
      district: newCam.district.trim(),
      department: newCam.department.trim(),
      status: newCam.status,
      source: newCam.source,
      x: 0,
      y: 0,
      latitude: Number(newCam.latitude) || 23.0225,
      longitude: Number(newCam.longitude) || 72.5714,
      coordinateSource: "Officer registered GPS",
      coordinateAccuracyMeters: newCam.coordinateAccuracyMeters,
      coordinateVerifiedAt: new Date().toISOString(),
      lastHeartbeat: "Stream connected",
      activity: "Live feed operational · 1920×1080 30fps",
      throughput: "3.2 Mbps",
      streamUrl: newCam.streamUrl.trim() || undefined,
      streamType: newCam.streamType,
    };

    saveCustomCamera(record);
    setLocalUpdateNonce((n) => n + 1);
    setSelected(record.id);
    setIsAddCameraOpen(false);
    setFeedback(`CCTV Camera ${record.id} (${record.name}) successfully added to active surveillance grid.`);
  }

  function handleBatchUpload(e: FormEvent) {
    e.preventDefault();
    if (!csvContent.trim()) {
      alert("Please paste CSV camera rows or upload a file.");
      return;
    }

    try {
      const lines = csvContent.trim().split("\n");
      let count = 0;
      for (const line of lines) {
        if (line.toLowerCase().startsWith("id,") || !line.trim()) continue;
        const [id, name, district, lat, lng, source] = line.split(",").map((s) => s?.trim());
        if (id && name) {
          const rec: CameraRecord = {
            id,
            name,
            district: district || "Gujarat Police Jurisdiction",
            department: "Gujarat Police Sentinel Sandbox",
            status: "online",
            source: source || "RTSP · H.264",
            x: 0,
            y: 0,
            latitude: Number(lat) || 23.0225,
            longitude: Number(lng) || 72.5714,
            coordinateSource: "Batch CSV import",
            coordinateAccuracyMeters: 20,
            coordinateVerifiedAt: new Date().toISOString(),
            lastHeartbeat: "Stream connected",
            activity: "Batch import · 1080p 25fps",
            throughput: "2.1 Mbps",
          };
          saveCustomCamera(rec);
          count++;
        }
      }
      setLocalUpdateNonce((n) => n + 1);
      setIsBatchOpen(false);
      setFeedback(`Successfully imported ${count} CCTV cameras into the registry!`);
    } catch {
      alert("Invalid CSV format. Please use: id,name,district,latitude,longitude,source");
    }
  }

  function loadSampleCSV() {
    setCsvContent(
      `id,name,district,latitude,longitude,source\nSENTINEL-31,SG Highway Iskcon Cross,Ahmedabad,23.0285,72.5065,RTSP\nSENTINEL-32,C.G. Road Panchvati,Ahmedabad,23.0212,72.5567,RTSP\nSENTINEL-33,Surat Ring Road Majura Gate,Surat,21.1762,72.8228,RTSP · HEVC\nSENTINEL-34,Vadodara Alkapuri Underpass,Vadodara,22.3107,73.1812,RTSP`,
    );
  }

  return (
    <div className="page-stack">
      <PageHeading
        eyebrow="STATE CCTV REGISTRY &amp; SURVEILLANCE MATRIX"
        title={
          <>
            Smart City Video Grid &amp;
            <br />
            <span>Live Camera Management.</span>
          </>
        }
        description="Monitor online CCTV streams across Gujarat in real-time. Add single cameras, upload batch camera manifests, or switch to the 3x3 Live Surveillance Video Matrix."
        actions={
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => setIsAddCameraOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-wider rounded transition-all shadow-md active:scale-95"
            >
              <Plus size={15} />
              <span>Add CCTV Camera</span>
            </button>
            <button
              type="button"
              onClick={() => setIsBatchOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-600 text-slate-200 font-semibold text-xs rounded transition-all"
            >
              <Upload size={14} />
              <span>Batch Import (CSV)</span>
            </button>
            <div className="flex items-center bg-slate-800 border border-slate-700 rounded p-0.5">
              <button
                type="button"
                onClick={() => setViewMode("detail")}
                title="Single Camera Stream Detail"
                className={`p-1.5 rounded text-xs font-semibold flex items-center gap-1 ${
                  viewMode === "detail" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                <List size={14} />
                <span className="hidden sm:inline">Details</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode("matrix")}
                title="3x3 Live Surveillance Matrix"
                className={`p-1.5 rounded text-xs font-semibold flex items-center gap-1 ${
                  viewMode === "matrix" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                <Grid size={14} />
                <span className="hidden sm:inline">Live Matrix (9)</span>
              </button>
            </div>
          </div>
        }
      />

      {feedback && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-600/70 text-emerald-300 text-xs rounded flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 size={16} className="text-emerald-400" />
            <span>{feedback}</span>
          </div>
          <button onClick={() => setFeedback("")} className="text-emerald-400 hover:text-white">
            <X size={14} />
          </button>
        </div>
      )}

      {/* Metrics Row */}
      <section className="metrics-grid registry-metrics">
        <MetricCard label="TOTAL CAMERAS REGISTERED" value={metrics.totalCameras} detail="Live published sources" icon={RadioTower} />
        <MetricCard label="STREAMING ONLINE" value={healthCounts.online} detail="Active RTSP / ANPR telemetry" icon={CheckCircle2} tone="green" />
        <MetricCard label="DEGRADED / OFFLINE" value={`${healthCounts.degraded} / ${healthCounts.offline}`} detail="Awaiting field service" icon={ShieldAlert} tone="amber" />
        <MetricCard label="TARGET DEPLOYMENT" value="80,000+" detail="Full Gujarat Smart Grid Target" icon={RadioTower} />
      </section>

      {/* 3x3 LIVE SURVEILLANCE MATRIX VIEW */}
      {viewMode === "matrix" ? (
        <section className="command-panel p-4">
          <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
            <div>
              <p className="eyebrow flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                POLICE HQ LIVE VIDEO WALL · 9 CHANNELS
              </p>
              <h2 className="text-base font-bold text-white tracking-wide">Multi-Camera Real-Time Grid View</h2>
            </div>
            <span className="text-xs font-mono text-slate-400">FPS: 29.8 · 1080p FHD · LOW LATENCY</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {rawCameras.slice(0, 9).map((cam) => (
              <div key={cam.id} className="relative group bg-slate-900 border border-slate-700/80 rounded-lg overflow-hidden">
                <LiveCCTVPlayer camera={cam} compact />
                <div className="p-2 bg-slate-950/90 border-t border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <strong className="text-white block text-xs truncate max-w-[180px]">{cam.name}</strong>
                    <span className="text-slate-400 text-[10px]">{cam.id} · {cam.district}</span>
                  </div>
                  <button
                    onClick={() => {
                      setSelected(cam.id);
                      setViewMode("detail");
                    }}
                    className="px-2 py-1 bg-slate-800 hover:bg-blue-600 text-slate-300 hover:text-white text-[10px] font-semibold rounded border border-slate-700"
                  >
                    Focus Cam
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      ) : (
        /* DETAIL TWO-COLUMN LAYOUT */
        <section className="registry-grid">
          {/* Left Column: Operational Camera Catalogue */}
          <article className="command-panel registry-list-panel">
            <SectionTitle eyebrow="CONNECTED VIDEO SOURCES" title="Operational Camera Catalogue" />

            <div className="registry-tools">
              <div className="registry-search">
                <Search size={15} />
                <input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Search camera name, district, or ID..."
                />
              </div>

              <div className="filter-row">
                <Filter size={14} />
                {filters.map((value) => (
                  <button
                    key={value}
                    onClick={() => setFilter(value)}
                    className={filter === value ? "filter-active" : ""}
                  >
                    {value}
                  </button>
                ))}
              </div>
            </div>

            <div className="registry-table-wrap">
              <table className="registry-table">
                <thead>
                  <tr>
                    <th>CAMERA</th>
                    <th>AREA / DISTRICT</th>
                    <th>FEED TYPE</th>
                    <th>STATUS</th>
                    <th>STREAM TELEMETRY</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((camera) => (
                    <tr
                      key={camera.id}
                      className={selectedCamera?.id === camera.id ? "registry-selected" : ""}
                      onClick={() => setSelected(camera.id)}
                    >
                      <td>
                        <button
                          className="registry-source-select"
                          onClick={() => setSelected(camera.id)}
                          aria-label={`Select ${camera.name}`}
                        >
                          <strong>{camera.name}</strong>
                          <span>{camera.id}</span>
                        </button>
                      </td>
                      <td>
                        <strong>{camera.district}</strong>
                        <span>{camera.department}</span>
                      </td>
                      <td>
                        <span className="source-badge">{camera.source}</span>
                      </td>
                      <td>
                        <StatusBadge status={camera.status} />
                      </td>
                      <td>
                        <strong>{camera.activity}</strong>
                        <span>{camera.lastHeartbeat} · {camera.throughput}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {visible.length === 0 ? (
                <div className="empty-state">
                  <SlidersHorizontal size={24} />
                  <strong>No camera sources match this filter</strong>
                  <span>Try a different status filter or search query.</span>
                </div>
              ) : null}
            </div>
          </article>

          {/* Right Column: Live Feed & Telemetry Player */}
          <aside className="command-panel registry-map-panel flex flex-col gap-4 p-4">
            {selectedCamera ? (
              <>
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div>
                    <p className="eyebrow">LIVE CCTV FEED · {selectedCamera.id}</p>
                    <h3 className="text-base font-bold text-white tracking-wide">{selectedCamera.name}</h3>
                  </div>
                  <StatusBadge status={selectedCamera.status} />
                </div>

                {/* Real-time Video Stream Component */}
                <div className="w-full">
                  <LiveCCTVPlayer camera={selectedCamera} />
                </div>

                {/* Camera Telemetry & Location Data */}
                <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-md text-xs space-y-2">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400">Jurisdiction:</span>
                    <strong>{selectedCamera.department}</strong>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400">District / Sub-area:</span>
                    <strong>{selectedCamera.district}</strong>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400">GPS Coordinates:</span>
                    <strong className="font-mono">
                      {selectedCamera.latitude ? `${selectedCamera.latitude.toFixed(4)}, ${selectedCamera.longitude.toFixed(4)}` : "Approximate"}
                    </strong>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400">FPS / Latency:</span>
                    <span className="font-mono text-emerald-400">{selectedTelemetry?.fps ?? "30 fps"} · {selectedTelemetry?.latency ?? "32 ms"}</span>
                  </div>
                </div>

                {/* Map Preview for selected camera */}
                <div className="mt-2">
                  <p className="eyebrow mb-1.5 flex items-center gap-1">
                    <MapPin size={12} className="text-blue-400" />
                    LOCATION RECON &amp; COVERAGE MAP
                  </p>
                  <CommandMap cameras={rawCameras} activeCameraId={selectedCamera.id} onCameraSelect={setSelected} compact />
                </div>
              </>
            ) : null}
          </aside>
        </section>
      )}

      {/* ADD CCTV CAMERA MODAL */}
      {isAddCameraOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-lg shadow-2xl p-6 text-white max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Video className="text-blue-400" size={18} />
                <h3 className="text-base font-bold text-white tracking-wide">Add CCTV Video Stream</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddCameraOpen(false)}
                className="text-slate-400 hover:text-white rounded p-1"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateCamera} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Camera ID</label>
                  <input
                    type="text"
                    required
                    value={newCam.id}
                    onChange={(e) => setNewCam({ ...newCam, id: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white font-mono outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Status</label>
                  <select
                    value={newCam.status}
                    onChange={(e) => setNewCam({ ...newCam, status: e.target.value as CameraStatus })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  >
                    <option value="online">Online &amp; Active</option>
                    <option value="degraded">Degraded Stream</option>
                    <option value="maintenance">Maintenance</option>
                    <option value="offline">Offline</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Camera Name / Landmark</label>
                <input
                  type="text"
                  required
                  value={newCam.name}
                  onChange={(e) => setNewCam({ ...newCam, name: e.target.value })}
                  placeholder="e.g. SG Highway Toll Plaza Gate #2"
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">District / Sub-area</label>
                  <input
                    type="text"
                    required
                    value={newCam.district}
                    onChange={(e) => setNewCam({ ...newCam, district: e.target.value })}
                    placeholder="Ahmedabad North"
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Protocol / Source</label>
                  <select
                    value={newCam.source}
                    onChange={(e) => setNewCam({ ...newCam, source: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                  >
                    <option value="RTSP · H.265">RTSP · H.265 (4K ANPR)</option>
                    <option value="RTSP · H.264">RTSP · H.264 (1080p FHD)</option>
                    <option value="HLS Live Stream">HLS Live Stream (.m3u8)</option>
                    <option value="ONVIF IP Dome">ONVIF IP PTZ Dome</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Latitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    required
                    value={newCam.latitude}
                    onChange={(e) => setNewCam({ ...newCam, latitude: parseFloat(e.target.value) })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white font-mono outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">Longitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    required
                    value={newCam.longitude}
                    onChange={(e) => setNewCam({ ...newCam, longitude: parseFloat(e.target.value) })}
                    className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white font-mono outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 uppercase mb-1">
                  Live Stream Feed URL (Optional - leave blank for Smart AI Feed)
                </label>
                <input
                  type="text"
                  value={newCam.streamUrl}
                  onChange={(e) => setNewCam({ ...newCam, streamUrl: e.target.value, streamType: e.target.value.endsWith(".mp4") ? "mp4" : "simulated" })}
                  placeholder="https://...mp4 or rtsp://..."
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-xs text-white outline-none focus:border-blue-500"
                />
                <span className="text-[10px] text-slate-400 block mt-1">
                  Leave empty to use Sentinel's live simulated 30fps AI telemetry matrix with optical ANPR tracking.
                </span>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddCameraOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold uppercase rounded shadow-lg"
                >
                  Register Camera
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* BATCH CSV IMPORT MODAL */}
      {isBatchOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-lg shadow-2xl p-6 text-white max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="text-emerald-400" size={18} />
                <h3 className="text-base font-bold text-white tracking-wide">Batch Upload Cameras via CSV</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsBatchOpen(false)}
                className="text-slate-400 hover:text-white rounded p-1"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleBatchUpload} className="space-y-4 mt-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-300">Format: id,name,district,latitude,longitude,source</span>
                <button
                  type="button"
                  onClick={loadSampleCSV}
                  className="text-xs text-blue-400 hover:underline flex items-center gap-1"
                >
                  <Download size={12} /> Load Sample Gujarat Cameras
                </button>
              </div>

              <textarea
                required
                rows={8}
                value={csvContent}
                onChange={(e) => setCsvContent(e.target.value)}
                placeholder="Paste CSV rows here or click 'Load Sample Gujarat Cameras' above..."
                className="w-full bg-slate-800 border border-slate-700 rounded p-3 text-xs text-white font-mono outline-none focus:border-blue-500"
              />

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsBatchOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase rounded shadow-lg"
                >
                  Import All Cameras
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
