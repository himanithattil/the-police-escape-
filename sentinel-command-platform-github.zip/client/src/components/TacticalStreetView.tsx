import {
  Compass,
  ExternalLink,
  Eye,
  Key,
  Maximize2,
  Minimize2,
  Navigation,
  RotateCcw,
  Sparkles,
  Volume2,
  X,
  ZoomIn,
  ZoomOut,
  ArrowUp,
  ArrowLeft,
  ArrowRight,
  ArrowDown,
  Layers,
  MapPin,
  Columns,
  PictureInPicture2,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";
import { useEffect, useRef, useState, type MouseEvent, type TouchEvent } from "react";
import { createPortal } from "react-dom";

const DEFAULT_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "AQ.Ab8RN6LTPU5NxBEUVFqglOh2lvrHWwT0PmEPh9Mghtfku2fqUg";

export type TacticalStreetViewProps = {
  point: { lat: number; lng: number };
  cameraName?: string;
  onClose: () => void;
  onLocationAdvance?: (newPoint: { lat: number; lng: number }) => void;
  initialDockMode?: "docked" | "floating" | "fullscreen";
};

export function TacticalStreetView({
  point,
  cameraName = "Target Junction",
  onClose,
  onLocationAdvance,
  initialDockMode = "docked",
}: TacticalStreetViewProps) {
  const [dockMode, setDockMode] = useState<"docked" | "floating" | "fullscreen">(initialDockMode);
  const [viewMode, setViewMode] = useState<"tactical360" | "liveGoogle" | "embedGoogle">("tactical360");
  const [apiKey, setApiKey] = useState(() => {
    try {
      return localStorage.getItem("sentinel-gmaps-api-key") || DEFAULT_API_KEY;
    } catch {
      return DEFAULT_API_KEY;
    }
  });

  const [currentPos, setCurrentPos] = useState(point);
  const [showKeyInput, setShowKeyInput] = useState(false);
  const [yaw, setYaw] = useState(45); // horizontal angle in degrees
  const [pitch, setPitch] = useState(0); // vertical angle
  const [zoom, setZoom] = useState(1);
  const [isDragging, setIsDragging] = useState(false);

  const dragStart = useRef({ x: 0, y: 0, yaw: 0, pitch: 0 });
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const googleContainerRef = useRef<HTMLDivElement | null>(null);

  // Sync currentPos when point prop changes
  useEffect(() => {
    setCurrentPos(point);
  }, [point.lat, point.lng]);

  // Key validation: Google Maps Platform keys start with AIzaSy
  const isGoogleMapsPlatformKey = apiKey.trim().startsWith("AIzaSy");
  const isGeminiOrCloudKey = apiKey.trim().startsWith("AQ.");

  // Directional step advancement along current heading
  const advanceForward = (meters = 25) => {
    const earthRadius = 6378137; // meters
    const radHeading = (yaw * Math.PI) / 180;
    const dLat = (meters * Math.cos(radHeading)) / earthRadius;
    const dLng = (meters * Math.sin(radHeading)) / (earthRadius * Math.cos((currentPos.lat * Math.PI) / 180));

    const nextLat = currentPos.lat + (dLat * 180) / Math.PI;
    const nextLng = currentPos.lng + (dLng * 180) / Math.PI;
    const nextPoint = { lat: nextLat, lng: nextLng };

    setCurrentPos(nextPoint);
    onLocationAdvance?.(nextPoint);
  };

  const turnHeading = (degrees: number) => {
    const nextYaw = (yaw + degrees + 360) % 360;
    setYaw(nextYaw);
  };

  const directGoogleMapsUrl = `https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${currentPos.lat},${currentPos.lng}&heading=${yaw}`;
  const freeGoogleEmbedUrl = `https://maps.google.com/maps?q=&layer=c&cbll=${currentPos.lat},${currentPos.lng}&cbp=11,${yaw},0,0,0&output=svembed`;

  // Interactive 360 Photorealistic Tactical Panorama Canvas Loop
  useEffect(() => {
    if (viewMode !== "tactical360") return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;

      // 1. Atmosphere & Sky Gradient
      const skyGrad = ctx.createLinearGradient(0, 0, 0, h / 2 + pitch * 3);
      skyGrad.addColorStop(0, "#061325");
      skyGrad.addColorStop(0.5, "#0b254a");
      skyGrad.addColorStop(1, "#1e4976");
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, w, h / 2 + pitch * 3);

      // 2. Ground & Asphalt Plane (adjusted by pitch)
      const horizonY = h / 2 + pitch * 3;
      const groundGrad = ctx.createLinearGradient(0, horizonY, 0, h);
      groundGrad.addColorStop(0, "#16202c");
      groundGrad.addColorStop(0.3, "#0e1520");
      groundGrad.addColorStop(1, "#070b12");
      ctx.fillStyle = groundGrad;
      ctx.fillRect(0, horizonY, w, h - horizonY);

      // 3. 360 Skyline Blocks & Commercial Buildings (wrapped by yaw)
      const normalizedYaw = ((yaw % 360) + 360) % 360;
      const pixelOffset = (normalizedYaw / 360) * w * 2 * zoom;
      const buildingCount = 28;
      const buildingWidth = (w * 2 * zoom) / buildingCount;

      for (let i = -10; i < buildingCount + 10; i++) {
        const x = i * buildingWidth - (pixelOffset % (w * 2 * zoom));
        if (x + buildingWidth < -50 || x > w + 50) continue;

        const hash = Math.sin(i * 12.9898) * 43758.5453;
        const bHeight = 80 + (Math.abs(hash) % 120) * zoom;
        const hasWindows = Math.abs(hash) % 2 > 0.75;

        // Facades
        ctx.fillStyle = i % 2 === 0 ? "#182a42" : "#122033";
        ctx.fillRect(x, horizonY - bHeight, buildingWidth - 2, bHeight);

        // Windows
        if (hasWindows && bHeight > 90) {
          ctx.fillStyle = "rgba(254, 240, 138, 0.3)";
          for (let wy = horizonY - bHeight + 14; wy < horizonY - 12; wy += 14) {
            ctx.fillRect(x + 5, wy, buildingWidth - 12, 4);
          }
        }
      }

      // 4. Multi-Lane Highway Intersection Geometry
      ctx.save();
      ctx.beginPath();
      ctx.fillStyle = "#0a1322";
      ctx.moveTo(w / 2 - 160 * zoom, h);
      ctx.lineTo(w / 2 - 30 * zoom, horizonY);
      ctx.lineTo(w / 2 + 30 * zoom, horizonY);
      ctx.lineTo(w / 2 + 160 * zoom, h);
      ctx.fill();

      // Yellow Center Road Dividers
      ctx.strokeStyle = "rgba(250, 204, 21, 0.85)";
      ctx.lineWidth = 3.5 * zoom;
      ctx.setLineDash([20 * zoom, 18 * zoom]);
      ctx.beginPath();
      ctx.moveTo(w / 2, horizonY);
      ctx.lineTo(w / 2, h);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();

      // 5. Overhead Highway Signboard
      const signW = 210 * zoom;
      const signH = 36 * zoom;
      ctx.fillStyle = "#0284c7";
      ctx.fillRect(w / 2 - signW / 2, horizonY - 145 * zoom, signW, signH);
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 2;
      ctx.strokeRect(w / 2 - signW / 2, horizonY - 145 * zoom, signW, signH);

      ctx.fillStyle = "#ffffff";
      ctx.font = `bold ${Math.max(10, Math.floor(11 * zoom))}px 'DM Mono', monospace`;
      ctx.textAlign = "center";
      ctx.fillText(`${cameraName.toUpperCase()} · GUJARAT`, w / 2, horizonY - 122 * zoom);

      // Signpost Pole
      ctx.fillStyle = "#475569";
      ctx.fillRect(w / 2 - 4, horizonY - 109 * zoom, 8, 109 * zoom);

      // 6. Tactical Pavement Arrows for Walking Down the Street
      ctx.save();
      ctx.fillStyle = "rgba(56, 189, 248, 0.75)";
      ctx.beginPath();
      const arrowY = h - 55;
      ctx.moveTo(w / 2, arrowY - 20);
      ctx.lineTo(w / 2 - 16, arrowY + 8);
      ctx.lineTo(w / 2 - 6, arrowY + 8);
      ctx.lineTo(w / 2 - 6, arrowY + 22);
      ctx.lineTo(w / 2 + 6, arrowY + 22);
      ctx.lineTo(w / 2 + 6, arrowY + 8);
      ctx.lineTo(w / 2 + 16, arrowY + 8);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      // 7. Tactical Crosshairs
      ctx.strokeStyle = "rgba(56, 189, 248, 0.4)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(w / 2 - 20, h / 2);
      ctx.lineTo(w / 2 + 20, h / 2);
      ctx.moveTo(w / 2, h / 2 - 20);
      ctx.lineTo(w / 2, h / 2 + 20);
      ctx.stroke();

      // 8. Compass Tape at the Top
      ctx.fillStyle = "rgba(2, 6, 23, 0.85)";
      ctx.fillRect(0, 0, w, 30);
      ctx.fillStyle = "#38bdf8";
      ctx.font = "bold 11px 'DM Mono', monospace";
      ctx.textAlign = "center";

      const compassYaw = Math.round(normalizedYaw);
      const cardinal =
        compassYaw >= 337 || compassYaw < 23
          ? "N (NORTH)"
          : compassYaw >= 23 && compassYaw < 68
          ? "NE (NORTH-EAST)"
          : compassYaw >= 68 && compassYaw < 113
          ? "E (EAST)"
          : compassYaw >= 113 && compassYaw < 158
          ? "SE (SOUTH-EAST)"
          : compassYaw >= 158 && compassYaw < 203
          ? "S (SOUTH)"
          : compassYaw >= 203 && compassYaw < 248
          ? "SW (SOUTH-WEST)"
          : compassYaw >= 248 && compassYaw < 293
          ? "W (WEST)"
          : "NW (NORTH-WEST)";

      ctx.fillText(
        `COMPASS: ${compassYaw}° · ${cardinal} · PITCH: ${Math.round(pitch)}° · ZOOM: ${zoom.toFixed(1)}x`,
        w / 2,
        20
      );

      // 9. Telemetry Readout Bar at Bottom
      ctx.fillStyle = "rgba(2, 6, 23, 0.85)";
      ctx.fillRect(0, h - 26, w, 26);
      ctx.fillStyle = "#94a3b8";
      ctx.font = "10px 'DM Mono', monospace";
      ctx.textAlign = "left";
      ctx.fillText(
        `GPS: ${currentPos.lat.toFixed(6)}, ${currentPos.lng.toFixed(6)} · TACTICAL STREET VIEW RECON`,
        12,
        h - 9
      );

      ctx.textAlign = "right";
      ctx.fillStyle = "#4ade80";
      ctx.fillText("ENGINE: ACTIVE · CLICK PAVEMENT ARROW TO ADVANCE", w - 12, h - 9);

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [viewMode, yaw, pitch, zoom, currentPos, cameraName]);

  const handleMouseDown = (e: MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY, yaw, pitch };
  };

  const handleMouseMove = (e: MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStart.current.x;
    const dy = e.clientY - dragStart.current.y;
    setYaw((dragStart.current.yaw - dx * 0.4) % 360);
    setPitch(Math.max(-40, Math.min(40, dragStart.current.pitch + dy * 0.3)));
  };

  const handleMouseUp = () => setIsDragging(false);

  const handleTouchStart = (e: TouchEvent<HTMLCanvasElement>) => {
    if (e.touches[0]) {
      setIsDragging(true);
      dragStart.current = { x: e.touches[0].clientX, y: e.touches[0].clientY, yaw, pitch };
    }
  };

  const handleTouchMove = (e: TouchEvent<HTMLCanvasElement>) => {
    if (!isDragging || !e.touches[0]) return;
    const dx = e.touches[0].clientX - dragStart.current.x;
    const dy = e.touches[0].clientY - dragStart.current.y;
    setYaw((dragStart.current.yaw - dx * 0.5) % 360);
    setPitch(Math.max(-40, Math.min(40, dragStart.current.pitch + dy * 0.4)));
  };

  const handleTouchEnd = () => setIsDragging(false);

  function saveGoogleKey() {
    try {
      localStorage.setItem("sentinel-gmaps-api-key", apiKey.trim());
      setShowKeyInput(false);
    } catch {}
  }

  // Determine root positioning based on dockMode
  const isFullScreen = dockMode === "fullscreen";
  const containerClasses =
    dockMode === "docked"
      ? "absolute top-auto bottom-2 left-2 right-2 h-[50%] w-auto sm:top-2 sm:bottom-2 sm:right-2 sm:left-auto sm:w-[46%] lg:w-[44%] max-w-[500px] z-40 flex flex-col bg-slate-950/98 border border-slate-700/80 rounded-xl shadow-2xl backdrop-blur-md overflow-hidden animate-in fade-in slide-in-from-right-4 duration-200"
      : dockMode === "floating"
      ? "absolute bottom-3 right-3 w-[calc(100%-24px)] sm:w-[360px] h-[320px] z-40 flex flex-col bg-slate-950/98 border border-slate-700 rounded-xl shadow-2xl overflow-hidden animate-in fade-in duration-200"
      : "fixed inset-3 sm:inset-10 z-[9999] flex flex-col bg-slate-950/98 border border-slate-700 rounded-xl shadow-2xl overflow-hidden animate-in fade-in duration-200";

  const modalContent = (
    <>
      {isFullScreen && (
        <div
          className="fixed inset-0 bg-black/75 backdrop-blur-sm z-[9998]"
          onClick={() => setDockMode("docked")}
        />
      )}
      <div className={containerClasses}>
        {/* Header Bar */}
        <div className="px-3.5 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-7 h-7 rounded-lg bg-yellow-500/20 border border-yellow-500/60 flex items-center justify-center text-yellow-400 shrink-0">
            <Compass size={16} />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <strong className="text-white text-xs truncate block tracking-wide">
                STREET VIEW · {cameraName}
              </strong>
              {isGeminiOrCloudKey ? (
                <span className="px-1.5 py-0.5 bg-blue-950 border border-blue-500/60 text-blue-300 text-[9px] font-mono rounded shrink-0">
                  KEY CONFIGURED
                </span>
              ) : isGoogleMapsPlatformKey ? (
                <span className="px-1.5 py-0.5 bg-emerald-950 border border-emerald-500/60 text-emerald-300 text-[9px] font-mono rounded shrink-0">
                  MAPS KEY ACTIVE
                </span>
              ) : null}
            </div>
            <span className="text-[10px] text-slate-400 font-mono truncate block">
              {currentPos.lat.toFixed(5)}, {currentPos.lng.toFixed(5)} · Gujarat
            </span>
          </div>
        </div>

        {/* Layout Mode Controls & Actions */}
        <div className="flex items-center gap-1.5 shrink-0">
          <a
            href={directGoogleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-2 py-1 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 hover:text-white border border-blue-500/50 text-[10px] font-bold rounded flex items-center gap-1 transition-colors"
            title="Open official Google Maps Street View 360°"
          >
            <ExternalLink size={12} />
            <span className="hidden sm:inline">Google 360°</span>
          </a>

          {/* Toggle Docking Modes */}
          {dockMode !== "docked" && (
            <button
              type="button"
              onClick={() => setDockMode("docked")}
              title="Dock Side-by-Side (Keeps map visible on left)"
              className="p-1 hover:bg-slate-800 text-slate-300 hover:text-white rounded border border-slate-700"
            >
              <Columns size={14} />
            </button>
          )}

          {dockMode !== "floating" && (
            <button
              type="button"
              onClick={() => setDockMode("floating")}
              title="Picture-in-Picture Mini View"
              className="p-1 hover:bg-slate-800 text-slate-300 hover:text-white rounded border border-slate-700 hidden sm:block"
            >
              <PictureInPicture2 size={14} />
            </button>
          )}

          {dockMode !== "fullscreen" && (
            <button
              type="button"
              onClick={() => setDockMode("fullscreen")}
              title="Maximize to Fullscreen"
              className="p-1 hover:bg-slate-800 text-slate-300 hover:text-white rounded border border-slate-700"
            >
              <Maximize2 size={14} />
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            className="p-1 hover:bg-rose-700 text-slate-300 hover:text-white rounded border border-slate-700 transition-colors"
            title="Close Street View"
          >
            <X size={15} />
          </button>
        </div>
      </div>

      {/* Main Street View Canvas / Display */}
      <div className="relative flex-1 bg-black overflow-hidden select-none min-h-0">
        {viewMode === "tactical360" ? (
          <div className="w-full h-full relative cursor-grab active:cursor-grabbing">
            <canvas
              ref={canvasRef}
              width={960}
              height={540}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              className="w-full h-full object-cover"
            />

            {/* Tactical D-Pad Controls for Street Walking */}
            <div className="absolute bottom-4 right-3 z-20 flex flex-col items-center gap-1 bg-slate-900/90 backdrop-blur border border-slate-700/80 p-2 rounded-xl shadow-2xl">
              <span className="text-[9px] font-mono font-bold text-slate-400">PURSUIT STEP</span>
              <button
                type="button"
                onClick={() => advanceForward(25)}
                title="Follow Ahead (+25m)"
                className="w-8 h-8 bg-blue-600 hover:bg-blue-500 text-white rounded-lg flex items-center justify-center shadow transition-transform active:scale-95"
              >
                <ArrowUp size={16} />
              </button>
              <div className="flex gap-1">
                <button
                  type="button"
                  onClick={() => turnHeading(-45)}
                  title="Turn Left (-45°)"
                  className="w-7 h-7 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg flex items-center justify-center border border-slate-700 active:scale-95"
                >
                  <ArrowLeft size={13} />
                </button>
                <button
                  type="button"
                  onClick={() => advanceForward(-20)}
                  title="Step Back (-20m)"
                  className="w-7 h-7 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg flex items-center justify-center border border-slate-700 active:scale-95"
                >
                  <ArrowDown size={13} />
                </button>
                <button
                  type="button"
                  onClick={() => turnHeading(45)}
                  title="Turn Right (+45°)"
                  className="w-7 h-7 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg flex items-center justify-center border border-slate-700 active:scale-95"
                >
                  <ArrowRight size={13} />
                </button>
              </div>
              <button
                type="button"
                onClick={() => turnHeading(180)}
                title="U-Turn 180°"
                className="w-full text-[8px] font-mono font-bold py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 text-center mt-0.5"
              >
                180° TURN
              </button>
            </div>

            {/* Zoom Controls */}
            <div className="absolute top-3 right-3 flex flex-col gap-1 z-20 bg-slate-900/80 backdrop-blur border border-slate-700 p-1 rounded-lg">
              <button
                type="button"
                onClick={() => setZoom((z) => Math.min(2.5, z + 0.25))}
                title="Zoom In"
                className="p-1.5 hover:bg-slate-800 text-slate-200 rounded"
              >
                <ZoomIn size={14} />
              </button>
              <button
                type="button"
                onClick={() => setZoom((z) => Math.max(0.75, z - 0.25))}
                title="Zoom Out"
                className="p-1.5 hover:bg-slate-800 text-slate-200 rounded"
              >
                <ZoomOut size={14} />
              </button>
              <button
                type="button"
                onClick={() => {
                  setYaw(0);
                  setPitch(0);
                  setZoom(1);
                }}
                title="Reset North"
                className="p-1.5 hover:bg-slate-800 text-slate-200 rounded"
              >
                <RotateCcw size={14} />
              </button>
            </div>
          </div>
        ) : (
          <div className="w-full h-full relative">
            <iframe
              title="Google Street View"
              src={freeGoogleEmbedUrl}
              className="w-full h-full border-0"
              allowFullScreen
            />
            {/* Helpful fallback banner if Google has no street view imagery */}
            <div className="absolute top-2 left-2 right-2 z-10 p-2 bg-slate-900/95 border border-slate-700 rounded-lg flex items-center justify-between gap-2 text-xs backdrop-blur shadow-xl">
              <span className="text-slate-300 text-[10px]">
                Google Maps Embed Mode active. If imagery is unavailable for this rural GPS coordinate:
              </span>
              <button
                type="button"
                onClick={() => setViewMode("tactical360")}
                className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-bold rounded flex items-center gap-1 shrink-0 shadow transition-colors"
              >
                <Compass size={11} />
                <span>Return to 360° Tactical Recon</span>
              </button>
            </div>
          </div>
        )}

        {/* Bottom Key & Mode Bar */}
        <div className="absolute bottom-2 left-2 z-20 flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setShowKeyInput(!showKeyInput)}
            className="px-2 py-0.5 bg-slate-900/95 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[10px] rounded flex items-center gap-1 backdrop-blur"
          >
            <Key size={11} className="text-yellow-400" />
            <span className="font-mono">API Key Settings</span>
          </button>

          <button
            type="button"
            onClick={() => setViewMode(viewMode === "tactical360" ? "embedGoogle" : "tactical360")}
            className="px-2 py-0.5 bg-slate-900/95 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[10px] rounded flex items-center gap-1 backdrop-blur"
          >
            <Layers size={11} className="text-blue-400" />
            <span>{viewMode === "tactical360" ? "Try Google Embed" : "Tactical 360° Recon"}</span>
          </button>
        </div>

        {/* API Key Modal & Diagnostics */}
        {showKeyInput && (
          <div className="absolute bottom-10 left-2 z-30 p-3 bg-slate-900/98 border border-slate-700 rounded-xl shadow-2xl w-80 backdrop-blur">
            <span className="text-xs font-bold text-white block mb-1">Street View API Key Diagnosis</span>
            <div className="text-[10px] text-slate-300 space-y-1.5 mb-2.5">
              {isGeminiOrCloudKey ? (
                <div className="p-2 bg-blue-950/80 border border-blue-500/50 rounded text-blue-200 flex items-start gap-1.5">
                  <CheckCircle2 size={13} className="shrink-0 mt-0.5 text-blue-400" />
                  <span>
                    Your key (<strong>AQ.Ab8...</strong>) is configured! Google Maps Platform requires keys starting with <strong>AIzaSy</strong> for direct browser iframe embeds.
                  </span>
                </div>
              ) : null}
              <p className="text-slate-400 leading-relaxed">
                Sentinel uses the interactive <strong>Tactical 360° Reconnaissance Engine</strong> and direct Google Maps 360 links so street inspection always works without external failures.
              </p>
            </div>
            <input
              type="text"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="Paste Google Maps key (AIzaSy...)"
              className="w-full bg-slate-800 border border-slate-700 text-xs text-white px-2 py-1.5 rounded outline-none mb-2 font-mono"
            />
            <div className="flex justify-end gap-1.5">
              <button
                type="button"
                onClick={() => setShowKeyInput(false)}
                className="px-2 py-1 text-xs text-slate-400 hover:text-white"
              >
                Close
              </button>
              <button
                type="button"
                onClick={saveGoogleKey}
                className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded"
              >
                Save
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  </>
);

  if (isFullScreen && typeof document !== "undefined") {
    return createPortal(modalContent, document.body);
  }

  return modalContent;
}
