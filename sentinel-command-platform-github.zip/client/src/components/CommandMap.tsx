import {
  Car,
  Compass,
  Crosshair,
  Flame,
  MapPin,
  Maximize2,
  Minimize2,
  Navigation,
  Radio,
  RotateCcw,
  Shield,
  ShieldAlert,
  Siren,
  Sparkles,
  Video,
  Eye,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  X,
  Clock,
  Radar,
} from "lucide-react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useEffect, useMemo, useRef, useState, type DragEvent } from "react";
import type { AlertRecord, CameraRecord, RoutePoint } from "@/lib/operations";
import { buildLocationSearchQuery, getCamera } from "@/lib/operations";
import { cn } from "@/lib/utils";
import { TacticalStreetView } from "./TacticalStreetView";
import { LiveCCTVPlayer } from "./LiveCCTVPlayer";

export type OfficerRouteGuidance = { distanceMeters: number; durationSeconds: number; targetLabel: string };
export type RoadRouteHypothesis = { index: number; label: string; distanceMeters: number; durationSeconds: number; roadSummary: string; legIndexes: number[] };

export type PolicePatrolUnit = {
  id: string;
  callsign: string;
  station: string;
  lat: number;
  lng: number;
  status: "patrolling" | "intercepting" | "dispatched";
};

export type EscapeCorridor = {
  id: string;
  name: string;
  bearingDeg: number;
  probability: number;
  distanceKm: number;
  targetPoint: LatLng;
  pathPoints: LatLng[];
};

export type InterceptCameraInfo = {
  camera: CameraRecord;
  location: CachedGeo;
  distanceMeters: number;
  etaSeconds: number;
  etaLabel: string;
  corridorName: string;
};

type CommandMapProps = {
  cameras: CameraRecord[];
  alerts?: AlertRecord[];
  route?: RoutePoint[];
  activeCameraId?: string;
  onCameraSelect?: (cameraId: string) => void;
  officerLocation?: { lat: number; lng: number } | null;
  onOfficerRouteChange?: (guidance: OfficerRouteGuidance | null) => void;
  onOfficerLocationChange?: (location: { lat: number; lng: number }) => void;
  onRoadRouteHypothesesChange?: (hypotheses: RoadRouteHypothesis[]) => void;
  onApproximateLocationsChange?: (cameraIds: string[]) => void;
  selectedRoadRouteIndex?: number;
  className?: string;
  compact?: boolean;
  interceptActive?: boolean;
  onDeployIntercept?: () => void;
};

type LatLng = { lat: number; lng: number };
type CachedGeo = { lat: number; lng: number; source: "nominatim" | "fallback" | "verified"; label: string };

const DEFAULT_CENTER: LatLng = { lat: 23.0225, lng: 72.5714 }; // Centered on Ahmedabad / Gujarat Command
const GEO_CACHE_KEY = "sentinel-camera-geocodes-v4";

// Verified Gujarat Camera GPS coordinates spread across arterial corridors
const VERIFIED_GUJARAT_CAMERA_COORDS: Record<string, { lat: number; lng: number; name: string; district: string }> = {
  "SENTINEL-1": { lat: 23.0375, lng: 72.5710, name: "Chiman bhai Bridge", district: "Ahmedabad Central" },
  "SENTINEL-2": { lat: 23.0385, lng: 72.5824, name: "Janpath Crossroad", district: "Ahmedabad East" },
  "SENTINEL-3": { lat: 23.1020, lng: 72.5940, name: "O.N.G.C. Office / Chandkheda", district: "Gandhinagar Link" },
  "SENTINEL-4": { lat: 23.0145, lng: 72.5612, name: "Paldi Circle Junction", district: "Ahmedabad West" },
  "SENTINEL-5": { lat: 23.0910, lng: 72.5930, name: "Visat teen Rasta", district: "Highway Checkpoint" },
  "SENTINEL-6": { lat: 21.5222, lng: 70.4579, name: "Timbavadi Gate Junagadh", district: "Junagadh Sector" },
  "SENTINEL-7": { lat: 20.9000, lng: 70.4000, name: "Hero Showroom Gir Somnath", district: "Gir Somnath" },
  "SENTINEL-8": { lat: 21.5300, lng: 70.4650, name: "Majewadi Gate Junagadh", district: "Junagadh North" },
  "SENTINEL-9": { lat: 21.5150, lng: 70.4450, name: "New Bypass Circle Junagadh", district: "Junagadh Bypass" },
  "SENTINEL-10": { lat: 21.5250, lng: 70.4700, name: "Char Chowk Road Junagadh", district: "Junagadh Central" },
  "SENTINEL-11": { lat: 21.5400, lng: 70.4500, name: "Dolatpara Junagadh", district: "Junagadh Industrial" },
  "SENTINEL-12": { lat: 23.1700, lng: 72.5850, name: "Tri Mandir Adalaj Tollnaka", district: "Adalaj Tollway" },
  "SENTINEL-13": { lat: 23.0304, lng: 72.5591, name: "CN Vidhyalaya Ambawadi", district: "Ahmedabad West" },
  "SENTINEL-14": { lat: 23.0388, lng: 72.5536, name: "Delight Crossroad", district: "Navrangpura" },
  "SENTINEL-15": { lat: 23.0187, lng: 72.5482, name: "Suvidha Park Junction", district: "Paldi South" },
  "SENTINEL-16": { lat: 23.0935, lng: 72.5910, name: "Visat P2 Highway", district: "Sabarmati Outer" },
  "SENTINEL-17": { lat: 22.3072, lng: 70.8028, name: "Rajkot Bus Port CCTV", district: "Rajkot Urban" },
  "SENTINEL-18": { lat: 22.3039, lng: 70.8022, name: "Rajkot Central CCTV", district: "Rajkot City" },
  "SENTINEL-19": { lat: 20.9467, lng: 72.9520, name: "Khaparia Gram Panchayat", district: "Navsari Highway" },
  "SENTINEL-20": { lat: 23.0350, lng: 72.6100, name: "Mohanpura Junction", district: "Asarwa Sector" },
  "SENTINEL-21": { lat: 23.8493, lng: 72.1266, name: "Patan Dethali Char Rasta", district: "Patan Outer" },
  "SENTINEL-22": { lat: 23.8600, lng: 72.1400, name: "BK Mervada tran Rasta", district: "Patan Highway" },
  "SENTINEL-23": { lat: 23.8300, lng: 72.1100, name: "Kheram Sector", district: "North Gujarat" },
  "SENTINEL-24": { lat: 23.1683, lng: 72.5594, name: "Dehgam Highway Checkpoint", district: "Dehgam Sector" },
  "SENTINEL-25": { lat: 20.9200, lng: 72.9300, name: "Dhanori Junction", district: "Navsari Link" },
  "SENTINEL-26": { lat: 21.3000, lng: 73.0000, name: "Tankal Arterial", district: "Surat Rural" },
  "SENTINEL-27": { lat: 20.7600, lng: 72.9600, name: "Bilimora South Checkpoint", district: "Bilimora Toll" },
  "SENTINEL-28": { lat: 20.7650, lng: 72.9650, name: "Bilimora Central Square", district: "Bilimora Market" },
  "SENTINEL-29": { lat: 20.7700, lng: 72.9700, name: "Bilimora North Overbridge", district: "Bilimora Highway" },
  "SENTINEL-30": { lat: 23.0753, lng: 70.1337, name: "Gandhidham Rambaugh P2", district: "Kutch Sector" },
  // Core Ahmedabad Highway Corridors
  "SENTINEL-SG-1": { lat: 23.0280, lng: 72.5070, name: "SG Highway Iskcon Crossroad", district: "SG Highway Core" },
  "SENTINEL-SG-2": { lat: 23.0110, lng: 72.5080, name: "SG Highway Prahlad Nagar", district: "SG Highway South" },
  "SENTINEL-SG-3": { lat: 23.0980, lng: 72.5310, name: "SG Highway Gota Flyover", district: "SG Highway North" },
  "SENTINEL-SG-4": { lat: 23.1250, lng: 72.5410, name: "SG Highway Vaishno Devi Circle", district: "Ring Road Interchange" },
};

// Active Gujarat Police Interceptor Squads
const DEFAULT_POLICE_UNITS: PolicePatrolUnit[] = [
  { id: "PCR-101", callsign: "PCR-101 Alpha", station: "Paldi Sector 3", lat: 23.0145, lng: 72.5612, status: "patrolling" },
  { id: "INT-204", callsign: "Interceptor-204 Bravo", station: "Janpath Highway Command", lat: 23.0385, lng: 72.5824, status: "patrolling" },
  { id: "SQUAD-308", callsign: "Highway Squad-308 Delta", station: "Visat Rapid Response", lat: 23.0910, lng: 72.5930, status: "patrolling" },
];

function readGeoCache(): Record<string, CachedGeo> {
  try {
    return JSON.parse(localStorage.getItem(GEO_CACHE_KEY) || "{}");
  } catch {
    return {};
  }
}

function writeGeoCache(cache: Record<string, CachedGeo>) {
  try {
    localStorage.setItem(GEO_CACHE_KEY, JSON.stringify(cache));
  } catch {}
}

function cameraIcon(
  camera: CameraRecord,
  alert: AlertRecord | undefined,
  selected: boolean,
  routeIndex: number,
  inEscapePath: boolean
) {
  const isOnline = camera.status === "online" || !camera.status || camera.status === "degraded";
  const label = routeIndex >= 0 ? String(routeIndex + 1) : "";

  return L.divIcon({
    className: "sentinel-live-cam-badge",
    iconSize: [44, 44],
    iconAnchor: [22, 22],
    html: `
      <div style="position:relative;width:40px;height:40px;display:flex;align-items:center;justify-content:center;">
        <!-- Pulsing Status Glow -->
        <div style="position:absolute;inset:0;border-radius:50%;background:${
          inEscapePath ? "rgba(245,158,11,0.25)" : "rgba(34,197,94,0.2)"
        };animation:camPulseRing 2s infinite;"></div>
        
        <!-- Camera Lens Circle -->
        <div class="sentinel-cam-core ${inEscapePath ? "sentinel-cam-intercept-alert" : ""}" style="width:34px;height:34px;border-radius:50%;background:#06152d;border:2px solid ${
      inEscapePath ? "#f59e0b" : selected ? "#38bdf8" : "#22c55e"
    };box-shadow:0 0 12px ${
      inEscapePath ? "rgba(245,158,11,0.8)" : "rgba(34,197,94,0.6)"
    };display:flex;align-items:center;justify-content:center;color:#fff;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${
            inEscapePath ? "#fbbf24" : "#4ade80"
          }" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="m22 8-6 4 6 4V8Z"/>
            <rect width="14" height="12" x="2" y="6" rx="2" ry="2"/>
          </svg>
        </div>

        <!-- ONLINE Pill Tag -->
        <div class="sentinel-cam-pill">
          <span class="dot"></span>${label ? `#${label} ` : ""}ONLINE
        </div>

        ${
          inEscapePath
            ? `<div class="sentinel-cam-intercept-pill">⚠️ IN ESCAPE PATH</div>`
            : ""
        }
      </div>
    `,
  });
}

function policeUnitIcon(unit: PolicePatrolUnit, isIntercepting: boolean) {
  return L.divIcon({
    className: "sentinel-police-icon",
    iconSize: [44, 44],
    iconAnchor: [22, 22],
    html: `
      <div style="position:relative;width:40px;height:40px;border-radius:8px;background:${isIntercepting ? "#dc2626" : "#1d4ed8"};border:2px solid #fff;box-shadow:0 0 14px ${isIntercepting ? "rgba(220,38,38,0.8)" : "rgba(29,78,216,0.8)"};display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;">
        <span style="font-size:16px;">🚔</span>
        <span style="position:absolute;bottom:-18px;background:#090d16;color:#60a5fa;border:1px solid #1e3a8a;border-radius:4px;padding:1px 4px;font:700 8px monospace;white-space:nowrap;">${unit.callsign.split(" ")[0]}</span>
      </div>
    `,
  });
}

function pegmanIcon() {
  return L.divIcon({
    className: "sentinel-pegman-icon",
    iconSize: [46, 56],
    iconAnchor: [23, 50],
    html: `
      <div style="width:42px;height:52px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;filter:drop-shadow(0 3px 8px rgba(0,0,0,0.7));cursor:grab;">
        <div style="position:relative;width:34px;height:44px;">
          <svg width="34" height="44" viewBox="0 0 34 46" xmlns="http://www.w3.org/2000/svg">
            <circle cx="17" cy="8" r="6" fill="#FACC15" stroke="#FFFFFF" stroke-width="2"/>
            <path d="M11 16c0-2 1.8-3.5 4-3.5h4c2.2 0 4 1.5 4 3.5v11l-3 0v14h-6V27h-3V16Z" fill="#FACC15" stroke="#FFFFFF" stroke-width="2" stroke-linejoin="round"/>
            <path d="M11 20 5 31M23 20l6 11" stroke="#FACC15" stroke-width="4" stroke-linecap="round"/>
            <path d="M12 41 9 45M22 41l3 4" stroke="#FACC15" stroke-width="4" stroke-linecap="round"/>
          </svg>
        </div>
        <div style="background:#020617;border:1px solid #facc15;color:#facc15;padding:1px 5px;border-radius:4px;font:800 8px monospace;margin-top:2px;white-space:nowrap;box-shadow:0 2px 4px rgba(0,0,0,0.8);">
          PEGMAN FUGITIVE
        </div>
      </div>
    `,
  });
}

// Distance between two coords in meters
function computeDistanceMeters(p1: LatLng, p2: LatLng): number {
  const R = 6371e3; // Earth radius in meters
  const lat1 = (p1.lat * Math.PI) / 180;
  const lat2 = (p2.lat * Math.PI) / 180;
  const dLat = ((p2.lat - p1.lat) * Math.PI) / 180;
  const dLng = ((p2.lng - p1.lng) * Math.PI) / 180;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

// Distance from point to line segment
function distToSegmentMeters(p: LatLng, v: LatLng, w: LatLng): number {
  const l2 = computeDistanceMeters(v, w) ** 2;
  if (l2 === 0) return computeDistanceMeters(p, v);
  let t = ((p.lat - v.lat) * (w.lat - v.lat) + (p.lng - v.lng) * (w.lng - v.lng)) /
    ((w.lat - v.lat) ** 2 + (w.lng - v.lng) ** 2);
  t = Math.max(0, Math.min(1, t));
  const projection: LatLng = {
    lat: v.lat + t * (w.lat - v.lat),
    lng: v.lng + t * (w.lng - v.lng),
  };
  return computeDistanceMeters(p, projection);
}

async function geocodeCamera(camera: CameraRecord): Promise<CachedGeo> {
  // 1. Direct verified coordinates on camera record
  if (camera.latitude !== 0 && camera.longitude !== 0) {
    return { lat: camera.latitude, lng: camera.longitude, source: "verified", label: `${camera.name} · Verified GPS` };
  }

  // 2. Verified Gujarat Law Enforcement Seed Dictionary
  const seedMatch = VERIFIED_GUJARAT_CAMERA_COORDS[camera.id];
  if (seedMatch) {
    return { lat: seedMatch.lat, lng: seedMatch.lng, source: "verified", label: `${seedMatch.name} · ${seedMatch.district}` };
  }

  // 3. Check LocalStorage Cache
  const cache = readGeoCache();
  if (cache[camera.id]) return cache[camera.id];

  // 4. Deterministic fallback distribution around Ahmedabad Command Center
  const hash = Array.from(camera.id).reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const angle = (hash % 360) * (Math.PI / 180);
  const radius = 0.015 + ((hash % 100) / 100) * 0.035; // 1.5km to 5km radius
  const lat = DEFAULT_CENTER.lat + radius * Math.cos(angle);
  const lng = DEFAULT_CENTER.lng + radius * Math.sin(angle);

  const value: CachedGeo = {
    lat,
    lng,
    source: "fallback",
    label: `${camera.name} · Gujarat Grid`,
  };

  cache[camera.id] = value;
  writeGeoCache(cache);
  return value;
}

async function routeBetween(points: LatLng[]): Promise<{ coordinates: LatLng[]; distance: number; duration: number } | null> {
  if (points.length < 2) return null;
  try {
    const coords = points.map((p) => `${p.lng},${p.lat}`).join(";");
    const response = await fetch(`https://router.project-osrm.org/route/v1/driving/${coords}?overview=full&geometries=geojson&alternatives=false&steps=false`);
    if (!response.ok) return null;
    const data = (await response.json()) as { routes?: Array<{ distance: number; duration: number; geometry?: { coordinates: number[][] } }> };
    const route = data.routes?.[0];
    if (!route?.geometry?.coordinates?.length) return null;
    return {
      coordinates: route.geometry.coordinates.map(([lng, lat]) => ({ lat, lng })),
      distance: route.distance,
      duration: route.duration,
    };
  } catch {
    return null;
  }
}

export function CommandMap({
  cameras,
  alerts = [],
  route = [],
  activeCameraId,
  onCameraSelect,
  officerLocation = null,
  onOfficerRouteChange,
  onOfficerLocationChange,
  onRoadRouteHypothesesChange,
  onApproximateLocationsChange,
  selectedRoadRouteIndex = 0,
  className,
  compact = false,
  interceptActive = false,
  onDeployIntercept,
}: CommandMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const cameraMarkers = useRef<Map<string, L.Marker>>(new Map());
  const policeMarkers = useRef<Map<string, L.Marker>>(new Map());
  const officerMarker = useRef<L.Marker | null>(null);
  const routeLine = useRef<L.Polyline | null>(null);
  const escapePolylines = useRef<L.Polyline[]>([]);
  const escapeMarkers = useRef<L.Marker[]>([]);
  const interceptLine = useRef<L.Polyline | null>(null);
  const roadblockCircle = useRef<L.Circle | null>(null);
  const initialViewportFitted = useRef(false);

  const [locations, setLocations] = useState<Record<string, CachedGeo>>({});
  const [pegmanDragging, setPegmanDragging] = useState(false);
  const [pegmanPos, setPegmanPos] = useState<LatLng>(() => officerLocation ?? DEFAULT_CENTER);
  const [streetViewPoint, setStreetViewPoint] = useState<LatLng | null>(null);
  const [streetViewCameraName, setStreetViewCameraName] = useState("Gujarat Command Checkpoint");
  const [activePreviewCamera, setActivePreviewCamera] = useState<CameraRecord | null>(null);
  const [status, setStatus] = useState("Gujarat Surveillance Grid · Online Cameras Active");
  const [hudExpanded, setHudExpanded] = useState(true);
  const [isMapExpanded, setIsMapExpanded] = useState(false);

  // Police Units State
  const [policeUnits] = useState<PolicePatrolUnit[]>(DEFAULT_POLICE_UNITS);

  // Escape Corridors State
  const [escapeCorridors, setEscapeCorridors] = useState<EscapeCorridor[]>([]);
  const [interceptCameras, setInterceptCameras] = useState<InterceptCameraInfo[]>([]);

  // Initialize Map
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;
    const map = L.map(containerRef.current, {
      center: [DEFAULT_CENTER.lat, DEFAULT_CENTER.lng],
      zoom: 12,
      zoomControl: true,
      preferCanvas: true,
    });

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: "&copy; OpenStreetMap contributors",
    }).addTo(map);

    mapRef.current = map;

    // Map click places / moves the Pegman
    map.on("click", (e: L.LeafletMouseEvent) => {
      const clicked = { lat: e.latlng.lat, lng: e.latlng.lng };
      setPegmanPos(clicked);
      onOfficerLocationChange?.(clicked);
    });

    return () => {
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sync external officerLocation prop to pegmanPos
  useEffect(() => {
    if (officerLocation) {
      setPegmanPos(officerLocation);
    }
  }, [officerLocation]);

  // Geocode Cameras with Verified Coordinates
  useEffect(() => {
    let cancelled = false;
    const loadAll = async () => {
      const next: Record<string, CachedGeo> = {};
      const approximateIds: string[] = [];
      for (const camera of cameras) {
        if (cancelled) return;
        const value = await geocodeCamera(camera);
        next[camera.id] = value;
        if (value.source === "fallback") approximateIds.push(camera.id);
        setLocations((current) => ({ ...current, [camera.id]: value }));
      }
      if (!cancelled) {
        setStatus(`${cameras.length} CCTV Cameras ONLINE · Street View Active`);
        onApproximateLocationsChange?.(approximateIds);
      }
    };
    void loadAll();
    return () => {
      cancelled = true;
    };
  }, [cameras.map((c) => `${c.id}:${c.latitude}:${c.longitude}:${c.name}`).join("|")]);

  // Expose global handlers for Leaflet HTML popups
  useEffect(() => {
    (window as any).__sentinel_recon = (_camId: string, lat: number, lng: number, name: string) => {
      setStreetViewCameraName(name);
      setStreetViewPoint({ lat, lng });
    };

    (window as any).__sentinel_live_cam = (camId: string) => {
      const cam = cameras.find((c) => c.id === camId);
      if (cam) setActivePreviewCamera(cam);
    };

    (window as any).__sentinel_dispatch_to = (lat: number, lng: number, camName: string) => {
      onDeployIntercept?.();
      setStatus(`🚨 PCR-101 Dispatched to Intercept at ${camName}`);
    };

    return () => {
      delete (window as any).__sentinel_recon;
      delete (window as any).__sentinel_live_cam;
      delete (window as any).__sentinel_dispatch_to;
    };
  }, [cameras, onDeployIntercept]);

  // =========================================================================
  // CALCULATE ESCAPE ROUTES (GREEN LINES) & INTERCEPT CAMERAS WHEN PEGMAN MOVES
  // =========================================================================
  useEffect(() => {
    if (!pegmanPos) return;

    // Define 5 strategic radial escape vectors radiating from Pegman
    const baseCorridors: Array<{
      id: string;
      name: string;
      bearingDeg: number;
      probability: number;
      distanceKm: number;
      dLat: number;
      dLng: number;
    }> = [
      {
        id: "CORR-1",
        name: "North Expressway Exit (Gandhinagar / Mehsana)",
        bearingDeg: 5,
        probability: 86,
        distanceKm: 2.6,
        dLat: 0.023,
        dLng: 0.003,
      },
      {
        id: "CORR-2",
        name: "North-East Arterial (Airport Ring Road Link)",
        bearingDeg: 48,
        probability: 74,
        distanceKm: 2.3,
        dLat: 0.016,
        dLng: 0.018,
      },
      {
        id: "CORR-3",
        name: "East Ring Road Expressway Link (CTM Bypass)",
        bearingDeg: 95,
        probability: 69,
        distanceKm: 2.5,
        dLat: -0.002,
        dLng: 0.024,
      },
      {
        id: "CORR-4",
        name: "South Arterial Highway (Toward Vadodara Express)",
        bearingDeg: 190,
        probability: 82,
        distanceKm: 2.8,
        dLat: -0.025,
        dLng: -0.004,
      },
      {
        id: "CORR-5",
        name: "West Sanand Bypass (Industrial Arterial)",
        bearingDeg: 280,
        probability: 62,
        distanceKm: 2.7,
        dLat: 0.005,
        dLng: -0.026,
      },
    ];

    let cancelled = false;

    // Build corridor objects with path waypoints
    const generated: EscapeCorridor[] = baseCorridors.map((b) => {
      const target: LatLng = {
        lat: pegmanPos.lat + b.dLat,
        lng: pegmanPos.lng + b.dLng,
      };

      // Synthesize realistic road-grid waypoints for instant zero-latency render
      const mid1: LatLng = {
        lat: pegmanPos.lat + b.dLat * 0.35 + (b.dLng > 0 ? 0.002 : -0.002),
        lng: pegmanPos.lng + b.dLng * 0.35,
      };
      const mid2: LatLng = {
        lat: pegmanPos.lat + b.dLat * 0.7,
        lng: pegmanPos.lng + b.dLng * 0.7 + (b.dLat > 0 ? -0.002 : 0.002),
      };

      return {
        id: b.id,
        name: b.name,
        bearingDeg: b.bearingDeg,
        probability: b.probability,
        distanceKm: b.distanceKm,
        targetPoint: target,
        pathPoints: [pegmanPos, mid1, mid2, target],
      };
    });

    setEscapeCorridors(generated);

    // Compute which cameras fall in the escape path
    const inPathList: InterceptCameraInfo[] = [];

    cameras.forEach((camera) => {
      const loc = locations[camera.id];
      if (!loc) return;

      const directDist = computeDistanceMeters(pegmanPos, loc);

      // Check distance to each escape route
      let minCorridorDist = Infinity;
      let matchedCorridor = generated[0];

      generated.forEach((corr) => {
        for (let i = 0; i < corr.pathPoints.length - 1; i++) {
          const segDist = distToSegmentMeters(loc, corr.pathPoints[i], corr.pathPoints[i + 1]);
          if (segDist < minCorridorDist) {
            minCorridorDist = segDist;
            matchedCorridor = corr;
          }
        }
      });

      // Camera falls in path if within 2.2km of Pegman OR within 550m of any escape corridor
      if (directDist <= 2400 || minCorridorDist <= 600) {
        const fugitiveSpeedKmh = 50; // Average pursuit transit speed in km/h
        const etaSec = Math.max(15, Math.round((directDist / ((fugitiveSpeedKmh * 1000) / 3600))));
        const etaLabel = etaSec < 60 ? `~${etaSec}s` : `~${Math.floor(etaSec / 60)}m ${etaSec % 60}s`;

        inPathList.push({
          camera,
          location: loc,
          distanceMeters: directDist,
          etaSeconds: etaSec,
          etaLabel,
          corridorName: matchedCorridor.name,
        });
      }
    });

    // Sort by proximity to Pegman (earliest interception point first)
    inPathList.sort((a, b) => a.distanceMeters - b.distanceMeters);
    setInterceptCameras(inPathList);

    // Optional: Query OSRM in background to enhance corridors with exact road curvature
    generated.forEach((corr, idx) => {
      void routeBetween([pegmanPos, corr.targetPoint]).then((res) => {
        if (!cancelled && res && res.coordinates.length > 2) {
          setEscapeCorridors((prev) => {
            const next = [...prev];
            if (next[idx]) {
              next[idx] = { ...next[idx], pathPoints: res.coordinates };
            }
            return next;
          });
        }
      });
    });

    return () => {
      cancelled = true;
    };
  }, [pegmanPos, cameras, locations]);

  // =========================================================================
  // RENDER GREEN ESCAPE ROUTES POLYLINES ON LEAFLET MAP
  // =========================================================================
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    // Clear previous escape polylines and markers
    escapePolylines.current.forEach((line) => line.remove());
    escapePolylines.current = [];
    escapeMarkers.current.forEach((marker) => marker.remove());
    escapeMarkers.current = [];

    escapeCorridors.forEach((corridor, idx) => {
      const latlngs = corridor.pathPoints.map((p) => [p.lat, p.lng] as [number, number]);

      // Bright vibrant green escape route polyline with animated flow dashes
      const polyline = L.polyline(latlngs, {
        color: "#22c55e",
        weight: 6,
        dashArray: "12 8",
        opacity: 0.95,
        className: "sentinel-escape-path",
      }).addTo(map);

      polyline.bindTooltip(
        `
        <div style="font-family:system-ui;padding:2px 4px;">
          <strong style="color:#16a34a;font-size:11px;">🟢 ESCAPE CORRIDOR #${idx + 1}</strong>
          <div style="font-size:10px;font-weight:700;color:#0f172a;">${corridor.name}</div>
          <div style="font-size:9px;color:#64748b;">Risk: ${corridor.probability}% · Length: ${corridor.distanceKm} km</div>
        </div>
      `,
        { sticky: true, opacity: 0.95 }
      );

      escapePolylines.current.push(polyline);

      // Perimeter Roadblock Marker at end of corridor
      const roadblockIcon = L.divIcon({
        className: "sentinel-roadblock-icon",
        iconSize: [28, 28],
        iconAnchor: [14, 14],
        html: `
          <div style="width:26px;height:26px;border-radius:50%;background:#ef4444;border:2px solid #fff;display:flex;align-items:center;justify-content:center;color:#fff;font:800 10px monospace;box-shadow:0 0 10px rgba(239,68,68,0.8);">
            🛑
          </div>
        `,
      });

      const endMarker = L.marker([corridor.targetPoint.lat, corridor.targetPoint.lng], {
        icon: roadblockIcon,
        title: `Seal Perimeter: ${corridor.name}`,
      }).addTo(map);

      endMarker.bindPopup(`
        <div style="font-family:system-ui;padding:4px;">
          <strong style="color:#dc2626;font-size:12px;">ROADBLOCK INTERCEPT SECTOR</strong>
          <span style="display:block;font-size:10px;color:#475569;margin:2px 0;">${corridor.name}</span>
          <span style="display:block;font-size:10px;color:#16a34a;font-weight:700;">Tactical Perimeter Seal Point</span>
          <button onclick="window.__sentinel_dispatch_to(${corridor.targetPoint.lat}, ${corridor.targetPoint.lng}, '${corridor.name}')" style="margin-top:6px;width:100%;background:#dc2626;color:#fff;border:0;padding:5px 8px;font-size:10px;font-weight:700;border-radius:4px;cursor:pointer;">
            DISPATCH INTERCEPT ROADBLOCK
          </button>
        </div>
      `);

      escapeMarkers.current.push(endMarker);
    });

    return () => {
      escapePolylines.current.forEach((line) => line.remove());
      escapePolylines.current = [];
      escapeMarkers.current.forEach((marker) => marker.remove());
      escapeMarkers.current = [];
    };
  }, [escapeCorridors]);

  // =========================================================================
  // RENDER CAMERA MARKERS WITH CLEAR ONLINE INDICATORS & ESCAPE PATH TAGS
  // =========================================================================
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const seen = new Set<string>();
    const interceptCameraIds = new Set(interceptCameras.map((c) => c.camera.id));

    cameras.forEach((camera) => {
      const location = locations[camera.id];
      if (!location) return;
      seen.add(camera.id);

      const relatedAlert = alerts.find((a) => a.cameraId === camera.id && a.status !== "resolved");
      const routeIndex = route.findIndex((p) => p.cameraId === camera.id);
      const inEscapePath = interceptCameraIds.has(camera.id);
      const icon = cameraIcon(camera, relatedAlert, activeCameraId === camera.id, routeIndex, inEscapePath);

      const existing = cameraMarkers.current.get(camera.id);

      if (!existing) {
        const created = L.marker([location.lat, location.lng], {
          icon,
          title: `${camera.name} · ONLINE (30 FPS Stream)`,
        }).addTo(map);

        created.on("click", () => {
          onCameraSelect?.(camera.id);
        });

        // Interactive Popup with Street View and CCTV Player triggers
        created.bindPopup(`
          <div style="font-family:system-ui;min-width:210px;padding:6px;">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:4px;">
              <strong style="font-size:12px;color:#0f172a;">${camera.name}</strong>
              <span style="background:#22c55e;color:#052e16;font-size:8px;font-weight:800;padding:1px 5px;border-radius:3px;font-family:monospace;">● ONLINE</span>
            </div>
            <span style="display:block;font-size:10px;color:#64748b;">${camera.district} · ${camera.id}</span>
            <span style="display:block;font-size:9px;color:#0284c7;font-family:monospace;margin:3px 0;">1080p FHD @ 30 FPS · ANPR Optical Engine</span>
            
            ${
              inEscapePath
                ? `<div style="background:#fef3c7;border:1px solid #f59e0b;color:#92400e;font-size:9px;font-weight:700;padding:2px 4px;border-radius:3px;margin:4px 0;">⚠️ LOCATED IN FUGITIVE ESCAPE PATH</div>`
                : ""
            }

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-top:8px;">
              <button onclick="window.__sentinel_recon('${camera.id}', ${location.lat}, ${location.lng}, '${camera.name}')" style="background:#2563eb;color:#fff;border:0;padding:5px 6px;font-size:10px;font-weight:700;border-radius:4px;cursor:pointer;">
                STREET VIEW
              </button>
              <button onclick="window.__sentinel_live_cam('${camera.id}')" style="background:#0f172a;color:#38bdf8;border:1px solid #38bdf8;padding:5px 6px;font-size:10px;font-weight:700;border-radius:4px;cursor:pointer;">
                LIVE FEED
              </button>
            </div>
          </div>
        `);

        cameraMarkers.current.set(camera.id, created);
      } else {
        existing.setLatLng([location.lat, location.lng]);
        existing.setIcon(icon);
      }
    });

    cameraMarkers.current.forEach((marker, id) => {
      if (!seen.has(id)) {
        marker.remove();
        cameraMarkers.current.delete(id);
      }
    });

    if (!initialViewportFitted.current) {
      const points = Object.values(locations).map((p) => [p.lat, p.lng] as [number, number]);
      if (points.length > 1) {
        map.fitBounds(L.latLngBounds(points), { padding: [40, 40], maxZoom: compact ? 11 : 13, animate: false });
        initialViewportFitted.current = true;
      }
    }
  }, [cameras, locations, alerts, activeCameraId, route, interceptCameras, onCameraSelect, compact]);

  // Render Police Interceptor Units
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    policeUnits.forEach((unit) => {
      const existing = policeMarkers.current.get(unit.id);
      const isIntercepting = interceptActive && unit.id === "PCR-101";
      const icon = policeUnitIcon(unit, isIntercepting);

      if (!existing) {
        const marker = L.marker([unit.lat, unit.lng], { icon, title: `${unit.callsign} · Active Patrol` }).addTo(map);
        marker.bindPopup(`
          <div style="font-family:system-ui;padding:4px;">
            <strong style="color:#1d4ed8;font-size:12px;">POLICE UNIT: ${unit.callsign}</strong>
            <span style="display:block;font-size:10px;color:#475569;">Jurisdiction: ${unit.station}</span>
            <span style="display:block;font-size:10px;color:#16a34a;font-weight:700;margin-top:2px;">STATUS: ${
              isIntercepting ? "INTERCEPTING SUSPECT" : "ACTIVE PATROL"
            }</span>
          </div>
        `);
        policeMarkers.current.set(unit.id, marker);
      } else {
        existing.setIcon(icon);
      }
    });
  }, [policeUnits, interceptActive]);

  // Suspect Trail Line
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    routeLine.current?.remove();
    routeLine.current = null;
    const points = route.map((p) => locations[p.cameraId]).filter(Boolean);
    if (points.length < 2) return;

    let cancelled = false;
    void routeBetween(points.map((p) => ({ lat: p.lat, lng: p.lng }))).then((result) => {
      if (cancelled || !result || !mapRef.current) return;
      routeLine.current = L.polyline(
        result.coordinates.map((p) => [p.lat, p.lng] as [number, number]),
        {
          color: "#e11d48",
          weight: 5,
          dashArray: "8 7",
          opacity: 0.95,
        }
      ).addTo(mapRef.current);
    });

    return () => {
      cancelled = true;
    };
  }, [route, locations]);

  // Tactical Intercept Vector Line & Roadblock Perimeter
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    interceptLine.current?.remove();
    interceptLine.current = null;
    roadblockCircle.current?.remove();
    roadblockCircle.current = null;

    if (!interceptActive) return;

    const pcr = policeUnits[0];
    const interceptTarget = escapeCorridors[0]?.targetPoint ?? { lat: 23.0910, lng: 72.5850 };

    void routeBetween([{ lat: pcr.lat, lng: pcr.lng }, interceptTarget]).then((result) => {
      if (!result || !mapRef.current) return;
      interceptLine.current = L.polyline(
        result.coordinates.map((p) => [p.lat, p.lng] as [number, number]),
        { color: "#06b6d4", weight: 6, dashArray: "10 6", opacity: 0.95 }
      ).addTo(mapRef.current);

      roadblockCircle.current = L.circle([interceptTarget.lat, interceptTarget.lng], {
        radius: 450,
        color: "#ef4444",
        fillColor: "#ef4444",
        fillOpacity: 0.25,
        dashArray: "6 6",
      }).addTo(mapRef.current);

      roadblockCircle.current.bindTooltip(
        "<strong>TACTICAL ROADBLOCK PERIMETER</strong><br>North Expressway Intercept Checkpoint",
        { permanent: true, direction: "top" }
      );
    });

    return () => {
      interceptLine.current?.remove();
      roadblockCircle.current?.remove();
    };
  }, [interceptActive, policeUnits, escapeCorridors]);

  // Draggable Pegman Marker
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (!officerMarker.current) {
      officerMarker.current = L.marker([pegmanPos.lat, pegmanPos.lng], {
        draggable: true,
        icon: pegmanIcon(),
        title: "Drag Pegman to project escape routes and inspect Street View",
      }).addTo(map);

      officerMarker.current.on("dragend", () => {
        const p = officerMarker.current?.getLatLng();
        if (p) {
          const next = { lat: p.lat, lng: p.lng };
          setPegmanPos(next);
          onOfficerLocationChange?.(next);
          setStreetViewPoint(next);
          setStreetViewCameraName("Pegman Field Location");
        }
      });
    } else {
      officerMarker.current.setLatLng([pegmanPos.lat, pegmanPos.lng]);
    }
  }, [pegmanPos, onOfficerLocationChange]);

  function placePegman(point: LatLng, name = "Inspected Junction") {
    setPegmanPos(point);
    onOfficerLocationChange?.(point);
    setStreetViewCameraName(name);
    setStreetViewPoint(point);
  }

  const handlePegmanDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setPegmanDragging(false);
    const map = mapRef.current;
    const rect = containerRef.current?.getBoundingClientRect();
    if (!map || !rect) return;
    const point = map.containerPointToLatLng(L.point(event.clientX - rect.left, event.clientY - rect.top));
    placePegman({ lat: point.lat, lng: point.lng }, "Street View Target");
  };

  const recenter = () => {
    const map = mapRef.current;
    const points = Object.values(locations).map((p) => [p.lat, p.lng] as [number, number]);
    if (map && points.length) map.fitBounds(L.latLngBounds(points), { padding: [40, 40], maxZoom: compact ? 11 : 13 });
  };

  const focusPegman = () => {
    mapRef.current?.setView([pegmanPos.lat, pegmanPos.lng], 14);
  };

  return (
    <div
      className={cn(
        "command-map command-map-leaflet relative select-none",
        isMapExpanded && "command-map-expanded",
        compact && !isMapExpanded && "command-map-compact",
        className
      )}
      onDragOver={(event) => {
        if (pegmanDragging) event.preventDefault();
      }}
      onDrop={handlePegmanDrop}
    >
      <div ref={containerRef} className="command-leaflet-surface" />

      {/* TACTICAL STREET VIEW RECON PANEL */}
      {streetViewPoint ? (
        <TacticalStreetView
          point={streetViewPoint}
          cameraName={streetViewCameraName}
          onClose={() => setStreetViewPoint(null)}
          onLocationAdvance={(newPos) => {
            setPegmanPos(newPos);
            onOfficerLocationChange?.(newPos);
          }}
        />
      ) : null}

      {/* LIVE CCTV CAMERA PREVIEW MODAL */}
      {activePreviewCamera && (
        <div className="fixed inset-4 sm:inset-12 z-50 flex flex-col bg-slate-950 border border-slate-700 rounded-xl shadow-2xl overflow-hidden animate-in fade-in">
          <div className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/50 flex items-center justify-center text-blue-400">
                <Video size={18} />
              </div>
              <div>
                <strong className="text-white text-sm block">{activePreviewCamera.name}</strong>
                <span className="text-xs text-slate-400 font-mono">
                  {activePreviewCamera.district} · {activePreviewCamera.id} · 30 FPS FHD Stream
                </span>
              </div>
            </div>
            <button
              onClick={() => setActivePreviewCamera(null)}
              className="p-1.5 bg-slate-800 hover:bg-rose-700 text-slate-300 hover:text-white rounded border border-slate-700"
            >
              <X size={16} />
            </button>
          </div>
          <div className="flex-1 p-4 bg-black flex items-center justify-center overflow-hidden">
            <LiveCCTVPlayer camera={activePreviewCamera} className="w-full h-full max-h-[75vh]" />
          </div>
        </div>
      )}

      {/* TOP STATUS OVERLAYS */}
      <div className="live-map-overlay live-map-overlay-top">
        <span className="live-map-overlay-dot" />
        {status}
      </div>

      {interceptActive && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 bg-rose-600 text-white px-4 py-1.5 rounded-full text-xs font-bold flex items-center gap-2 shadow-2xl border border-rose-300 animate-pulse">
          <Siren size={15} className="animate-spin" />
          <span>POLICE INTERCEPT VECTOR ARMED · PCR-101 ALPHA DISPATCHED · ETA 2M 15S</span>
        </div>
      )}

      {/* STREET VIEW PEGMAN HANDLE */}
      <div className="pegman-control" aria-label="Street View Pegman">
        <span
          className="pegman-handle cursor-grab active:cursor-grabbing"
          draggable
          onDragStart={() => setPegmanDragging(true)}
          onDragEnd={() => setPegmanDragging(false)}
          onClick={() => {
            placePegman(pegmanPos, "Gujarat Tactical Sector");
          }}
          title="Drag Pegman onto map to see escape routes and Street View"
        >
          <span className="pegman-icon">
            <i />
          </span>
        </span>
        <strong>PEGMAN RADAR</strong>
        <small>Place to show green escape routes & cameras</small>
      </div>

      {pegmanDragging && (
        <div className="pegman-drag-ghost">
          <span className="pegman-icon">
            <i />
          </span>
        </div>
      )}

      {/* MAP LEGEND */}
      <div className="map-legend live-map-legend">
        <span><i className="legend-dot online" />Online Camera</span>
        <span><i className="legend-dot degraded" style={{ background: "#f59e0b" }} />In Escape Path</span>
        <span><i className="legend-line" style={{ borderTop: "3px dashed #22c55e" }} />Green Escape Corridors</span>
        <span><span style={{ fontSize: 13 }}>🚔</span> Patrol Interceptor</span>
      </div>

      {/* FLOATING MAP CONTROLS */}
      <div className="map-controls">
        <button
          onClick={() => {
            const next = !isMapExpanded;
            setIsMapExpanded(next);
            setTimeout(() => {
              mapRef.current?.invalidateSize();
            }, 260);
          }}
          title={isMapExpanded ? "Restore Normal Height (620px)" : "Expand Map Height (780px Full Console)"}
        >
          {isMapExpanded ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
        </button>
        <button onClick={recenter} title="Recenter Grid">
          <RotateCcw size={15} />
        </button>
        <button onClick={focusPegman} title="Focus Pegman Fugitive">
          <Crosshair size={15} className="text-yellow-400" />
        </button>
        <button
          onClick={() => placePegman(pegmanPos, "Pegman Active Sector")}
          title="Launch Live Street View with API Key"
        >
          <Compass size={15} className="text-yellow-400" />
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TACTICAL ESCAPE RADAR & INTERCEPT CAMERAS HUD PANEL (USER REQUIREMENT 3 & 4) */}
      {/* ========================================================================= */}
      <div
        className={`absolute bottom-3 left-3 z-30 w-[calc(100%-24px)] sm:w-96 max-w-[420px] bg-slate-950/95 border border-emerald-500/50 rounded-xl shadow-2xl backdrop-blur-md overflow-hidden animate-in fade-in ${
          streetViewPoint ? "hidden sm:block" : "block"
        }`}
      >
        {/* Panel Header */}
        <div className="p-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-emerald-500/20 border border-emerald-500/60 flex items-center justify-center text-emerald-400">
              <Radar size={16} className="animate-spin" style={{ animationDuration: "6s" }} />
            </div>
            <div>
              <strong className="text-xs text-white block tracking-wide">
                FUGITIVE ESCAPE RADAR & INTERCEPT CAMERAS
              </strong>
              <span className="text-[10px] text-emerald-400 font-mono block">
                Origin: {pegmanPos.lat.toFixed(4)}, {pegmanPos.lng.toFixed(4)} · 5 Green Corridors
              </span>
            </div>
          </div>
          <button
            onClick={() => setHudExpanded(!hudExpanded)}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded"
          >
            {hudExpanded ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
          </button>
        </div>

        {hudExpanded && (
          <div className="p-3 max-h-72 overflow-y-auto space-y-2">
            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-1.5 pb-2 border-b border-slate-800/80 text-center font-mono">
              <div className="p-1.5 bg-slate-900 rounded border border-slate-800">
                <span className="text-[9px] text-slate-400 block">ESCAPE ROUTES</span>
                <strong className="text-xs text-emerald-400">5 Mapped</strong>
              </div>
              <div className="p-1.5 bg-slate-900 rounded border border-slate-800">
                <span className="text-[9px] text-slate-400 block">CAMERAS IN PATH</span>
                <strong className="text-xs text-amber-400">{interceptCameras.length} Active</strong>
              </div>
              <div className="p-1.5 bg-slate-900 rounded border border-slate-800">
                <span className="text-[9px] text-slate-400 block">INTERCEPT TIME</span>
                <strong className="text-xs text-cyan-400">
                  {interceptCameras[0]?.etaLabel ?? "Immediate"}
                </strong>
              </div>
            </div>

            {/* List of Cameras Falling in Pegman's Way */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] font-bold text-slate-300 font-mono block uppercase">
                Cameras Along Escape Trajectory (Closest First):
              </span>

              {interceptCameras.length === 0 ? (
                <div className="p-3 bg-slate-900/50 rounded text-center text-xs text-slate-400">
                  Drag the Pegman closer to city junctions to calculate intercept cameras.
                </div>
              ) : (
                interceptCameras.map((item, idx) => (
                  <div
                    key={item.camera.id}
                    className="p-2.5 bg-slate-900/80 hover:bg-slate-850 border border-slate-800 rounded-lg transition-colors flex flex-col gap-1.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold flex items-center justify-center font-mono">
                            {idx + 1}
                          </span>
                          <strong className="text-xs text-white">{item.camera.name}</strong>
                        </div>
                        <span className="text-[10px] text-slate-400 block font-mono">
                          {item.camera.district} · {item.distanceMeters} m away
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="px-1.5 py-0.5 bg-emerald-950 border border-emerald-600/50 text-emerald-400 text-[9px] font-bold font-mono rounded">
                          ● ONLINE
                        </span>
                        <span className="text-[10px] text-cyan-400 font-mono font-bold block mt-1">
                          ETA {item.etaLabel}
                        </span>
                      </div>
                    </div>

                    <div className="text-[10px] text-slate-400 bg-slate-950/70 p-1.5 rounded border border-slate-800/80 flex items-center justify-between">
                      <span className="truncate pr-2">Guards: {item.corridorName}</span>
                    </div>

                    {/* Quick action buttons */}
                    <div className="flex items-center gap-1.5 pt-0.5">
                      <button
                        type="button"
                        onClick={() => setActivePreviewCamera(item.camera)}
                        className="flex-1 py-1 px-2 bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/50 text-blue-300 rounded text-[10px] font-semibold flex items-center justify-center gap-1"
                      >
                        <Video size={11} />
                        <span>Live Feed</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setStreetViewCameraName(item.camera.name);
                          setStreetViewPoint({ lat: item.location.lat, lng: item.location.lng });
                        }}
                        className="flex-1 py-1 px-2 bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/50 text-yellow-300 rounded text-[10px] font-semibold flex items-center justify-center gap-1"
                      >
                        <Compass size={11} />
                        <span>Street View</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onDeployIntercept?.();
                          setStatus(`🚔 Dispatched PCR-101 to Intercept at ${item.camera.name}`);
                        }}
                        className="flex-1 py-1 px-2 bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/50 text-rose-300 rounded text-[10px] font-semibold flex items-center justify-center gap-1"
                      >
                        <Siren size={11} />
                        <span>Blockade</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
