import {
  Camera,
  Maximize2,
  Minimize2,
  Moon,
  Radio,
  RefreshCw,
  Sun,
  Video,
  Volume2,
  VolumeX,
  ZoomIn,
  ZoomOut,
  Sparkles,
  Download,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { CameraRecord } from "@/lib/operations";

type LiveCCTVPlayerProps = {
  camera: CameraRecord;
  className?: string;
  onSnapshot?: (dataUrl: string) => void;
  compact?: boolean;
};

export function LiveCCTVPlayer({ camera, className = "", onSnapshot, compact = false }: LiveCCTVPlayerProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [zoomLevel, setZoomLevel] = useState<1 | 2 | 4>(1);
  const [nightVision, setNightVision] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [lastSnapshot, setLastSnapshot] = useState<string | null>(null);
  const [snapshotAlert, setSnapshotAlert] = useState(false);
  const [streamHealth, setStreamHealth] = useState({ fps: 29.8, bitrate: "2.4 Mbps", latency: "38 ms" });

  // Use real HTML video if a real video URL is present and not simulated
  const isCustomVideo = Boolean(camera.streamUrl && !camera.streamUrl.includes("simulated") && camera.streamType === "mp4");

  useEffect(() => {
    if (isCustomVideo) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let frameCount = 0;
    let lastTime = performance.now();

    // Simulated targets moving across camera field
    const targets = [
      { id: "T-1", type: "VEHICLE", label: "GJ01QX4821", x: 40, y: 140, speed: 1.4, width: 90, height: 50, color: "#22c55e", score: "98.4%" },
      { id: "T-2", type: "VEHICLE", label: "GJ05KR9013", x: 320, y: 190, speed: -1.8, width: 85, height: 48, color: "#f59e0b", score: "96.1%" },
      { id: "T-3", type: "PEDESTRIAN", label: "SUBJECT #08", x: 190, y: 90, speed: 0.5, width: 26, height: 55, color: "#38bdf8", score: "91.8%" },
    ];

    const render = (now: number) => {
      frameCount++;
      if (now - lastTime >= 1000) {
        setStreamHealth((prev) => ({
          ...prev,
          fps: Math.round((frameCount * 1000) / (now - lastTime) * 10) / 10,
        }));
        frameCount = 0;
        lastTime = now;
      }

      const w = canvas.width;
      const h = canvas.height;

      // Background Scene (Highway / Intersection)
      if (nightVision) {
        ctx.fillStyle = "#031508";
        ctx.fillRect(0, 0, w, h);
        // Greenish scanlines
        ctx.fillStyle = "rgba(0, 255, 65, 0.04)";
        for (let i = 0; i < h; i += 3) {
          ctx.fillRect(0, i, w, 1);
        }
      } else {
        // Dark Asphalt / City C&C Surveillance Tone
        ctx.fillStyle = "#0c1524";
        ctx.fillRect(0, 0, w, h);

        // Road Surface Perspective
        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, "#132138");
        grad.addColorStop(1, "#070e1b");
        ctx.fillStyle = grad;
        ctx.fillRect(0, 60, w, h - 60);

        // Lane markings
        ctx.strokeStyle = "rgba(255, 255, 255, 0.25)";
        ctx.lineWidth = 2;
        ctx.setLineDash([16, 16]);
        ctx.beginPath();
        ctx.moveTo(0, 160);
        ctx.lineTo(w, 160);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Draw Horizon & Distant Infrastructure
      ctx.fillStyle = nightVision ? "#052e12" : "#1a2c47";
      ctx.fillRect(0, 0, w, 65);
      // Streetlights
      ctx.fillStyle = nightVision ? "rgba(74, 222, 128, 0.3)" : "rgba(251, 191, 36, 0.4)";
      ctx.beginPath();
      ctx.arc(80, 50, 15, 0, Math.PI * 2);
      ctx.arc(280, 48, 14, 0, Math.PI * 2);
      ctx.arc(480, 52, 16, 0, Math.PI * 2);
      ctx.fill();

      // Update and Draw Moving Targets
      targets.forEach((t) => {
        t.x += t.speed;
        if (t.speed > 0 && t.x > w + 20) t.x = -100;
        if (t.speed < 0 && t.x < -100) t.x = w + 20;

        // Vehicle / Subject Silhouette
        ctx.fillStyle = nightVision ? "#14532d" : t.type === "VEHICLE" ? "#243c5a" : "#334155";
        ctx.beginPath();
        if (t.type === "VEHICLE") {
          ctx.roundRect(t.x, t.y, t.width, t.height, 6);
        } else {
          ctx.roundRect(t.x, t.y, t.width, t.height, 4);
        }
        ctx.fill();

        // AI Bounding Box
        ctx.strokeStyle = nightVision ? "#4ade80" : t.color;
        ctx.lineWidth = 1.5;
        ctx.strokeRect(t.x - 4, t.y - 4, t.width + 8, t.height + 8);

        // Corner tick marks
        const cl = 6;
        ctx.lineWidth = 3;
        // Top-left
        ctx.beginPath();
        ctx.moveTo(t.x - 4, t.y - 4 + cl);
        ctx.lineTo(t.x - 4, t.y - 4);
        ctx.lineTo(t.x - 4 + cl, t.y - 4);
        // Top-right
        ctx.moveTo(t.x + t.width + 4 - cl, t.y - 4);
        ctx.lineTo(t.x + t.width + 4, t.y - 4);
        ctx.lineTo(t.x + t.width + 4, t.y - 4 + cl);
        // Bottom-left
        ctx.moveTo(t.x - 4, t.y + t.height + 4 - cl);
        ctx.lineTo(t.x - 4, t.y + t.height + 4);
        ctx.lineTo(t.x - 4 + cl, t.y + t.height + 4);
        // Bottom-right
        ctx.moveTo(t.x + t.width + 4 - cl, t.y + t.height + 4);
        ctx.lineTo(t.x + t.width + 4, t.y + t.height + 4);
        ctx.lineTo(t.x + t.width + 4, t.y + t.height + 4 - cl);
        ctx.stroke();

        // Target Tag / OCR Plate Badge
        ctx.fillStyle = nightVision ? "#052e12" : "#090d16";
        ctx.fillRect(t.x - 4, t.y - 20, t.width + 8, 14);
        ctx.fillStyle = nightVision ? "#4ade80" : "#ffffff";
        ctx.font = "bold 9px 'DM Mono', monospace";
        ctx.fillText(`${t.label} · ${t.score}`, t.x, t.y - 10);
      });

      // Camera Optical HUD Overlay
      const nowIso = new Date();
      const dateStr = nowIso.toISOString().slice(0, 10);
      const timeStr = `${nowIso.toLocaleTimeString()} .${String(nowIso.getMilliseconds()).padStart(3, "0")}`;

      // Military timestamp bar
      ctx.fillStyle = "rgba(0, 0, 0, 0.65)";
      ctx.fillRect(0, 0, w, 22);

      ctx.fillStyle = nightVision ? "#86efac" : "#f1f5f9";
      ctx.font = "bold 10px 'DM Mono', monospace";
      ctx.fillText(`CAM: ${camera.id} · ${camera.name.toUpperCase()} · ${camera.district}`, 10, 15);

      ctx.textAlign = "right";
      ctx.fillText(`${dateStr} ${timeStr} IST`, w - 10, 15);
      ctx.textAlign = "left";

      // Bottom Telemetry Bar
      ctx.fillStyle = "rgba(0, 0, 0, 0.65)";
      ctx.fillRect(0, h - 22, w, 22);

      ctx.fillStyle = nightVision ? "#86efac" : "#94a3b8";
      ctx.font = "9px 'DM Mono', monospace";
      ctx.fillText(`LIVE RTSP · H.265 · ${streamHealth.fps} FPS · ${streamHealth.bitrate} · LAT: ${streamHealth.latency}`, 10, h - 8);

      // Blinking Red REC Indicator
      if (Math.floor(now / 600) % 2 === 0) {
        ctx.fillStyle = "#ef4444";
        ctx.beginPath();
        ctx.arc(w - 45, h - 11, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#ffffff";
        ctx.fillText("REC", w - 35, h - 8);
      }

      // Crosshair Center
      ctx.strokeStyle = nightVision ? "rgba(74, 222, 128, 0.4)" : "rgba(255, 255, 255, 0.3)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(w / 2 - 12, h / 2);
      ctx.lineTo(w / 2 + 12, h / 2);
      ctx.moveTo(w / 2, h / 2 - 12);
      ctx.lineTo(w / 2, h / 2 + 12);
      ctx.stroke();

      animationId = requestAnimationFrame(render);
    };

    animationId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animationId);
  }, [camera, nightVision, isCustomVideo, streamHealth.fps]);

  function takeSnapshot() {
    let dataUrl = "";
    if (isCustomVideo) {
      // If custom video, capture via offscreen canvas
      const offscreen = document.createElement("canvas");
      offscreen.width = 640;
      offscreen.height = 360;
      const ctx = offscreen.getContext("2d");
      if (ctx) {
        ctx.fillStyle = "#0f172a";
        ctx.fillRect(0, 0, 640, 360);
        ctx.fillStyle = "#ffffff";
        ctx.font = "14px monospace";
        ctx.fillText(`CCTV SNAPSHOT: ${camera.id} · ${camera.name}`, 20, 40);
        ctx.fillText(`TIMESTAMP: ${new Date().toISOString()} IST`, 20, 70);
      }
      dataUrl = offscreen.toDataURL("image/jpeg", 0.9);
    } else {
      const canvas = canvasRef.current;
      if (canvas) {
        dataUrl = canvas.toDataURL("image/jpeg", 0.92);
      }
    }

    if (dataUrl) {
      setLastSnapshot(dataUrl);
      setSnapshotAlert(true);
      setTimeout(() => setSnapshotAlert(false), 3000);
      onSnapshot?.(dataUrl);
    }
  }

  function toggleFullscreen() {
    if (!containerRef.current) return;
    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen();
      }
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
      setIsFullscreen(false);
    }
  }

  return (
    <div
      ref={containerRef}
      className={`relative overflow-hidden rounded-lg border border-slate-700/80 bg-black ${className}`}
      style={{
        transform: zoomLevel > 1 ? `scale(${zoomLevel})` : "none",
        transformOrigin: "center center",
        transition: "transform 200ms ease",
      }}
    >
      {/* Real Video or Simulated Canvas */}
      {isCustomVideo ? (
        <video
          src={camera.streamUrl}
          autoPlay
          loop
          muted
          playsInline
          className={`w-full h-full object-cover ${nightVision ? "filter hue-rotate-90 brightness-125 contrast-150" : ""}`}
        />
      ) : (
        <canvas
          ref={canvasRef}
          width={640}
          height={360}
          className="w-full h-auto block aspect-video object-cover"
        />
      )}

      {/* Top Floating Controls */}
      <div className="absolute top-2 right-2 flex items-center gap-1.5 z-10 bg-black/60 backdrop-blur-md px-2 py-1 rounded-md border border-white/10">
        <button
          type="button"
          onClick={() => setNightVision(!nightVision)}
          title={nightVision ? "Switch to Standard View" : "Switch to Night-Vision IR"}
          className={`p-1 rounded text-xs transition-colors ${nightVision ? "bg-emerald-600 text-white" : "text-slate-300 hover:text-white"}`}
        >
          {nightVision ? <Sun size={13} /> : <Moon size={13} />}
        </button>

        <button
          type="button"
          onClick={() => setZoomLevel((z) => (z === 1 ? 2 : z === 2 ? 4 : 1))}
          title={`Zoom Level: ${zoomLevel}x (Click to cycle)`}
          className="p-1 text-slate-300 hover:text-white rounded text-[11px] font-mono font-bold"
        >
          {zoomLevel}x
        </button>

        <button
          type="button"
          onClick={takeSnapshot}
          title="Take Forensic Snapshot"
          className="p-1 text-slate-300 hover:text-white rounded transition-colors"
        >
          <Camera size={13} />
        </button>

        {!compact && (
          <button
            type="button"
            onClick={toggleFullscreen}
            title="Toggle Fullscreen"
            className="p-1 text-slate-300 hover:text-white rounded transition-colors"
          >
            {isFullscreen ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
          </button>
        )}
      </div>

      {/* Snapshot Confirmation Pill */}
      {snapshotAlert && (
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 bg-emerald-600 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5 shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-150">
          <Camera size={12} />
          <span>Forensic Frame Captured!</span>
          {lastSnapshot && (
            <a
              href={lastSnapshot}
              download={`${camera.id}_snapshot.jpg`}
              className="underline ml-1 font-bold hover:text-emerald-100"
            >
              Save
            </a>
          )}
        </div>
      )}
    </div>
  );
}
