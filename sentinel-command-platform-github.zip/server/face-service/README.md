# Sentinel Face-Verify Microservice

FastAPI service that powers the **AI Face Detection** page inside Sentinel.

## Pipeline

1. Detect & crop primary face (DeepFace + RetinaFace / OpenCV fallback)
2. Upload crop to Cloudinary → public URL
3. SerpAPI Google Lens → visual matches
4. Parallel Facenet512 biometric matching
5. Anchor best social post hash on Ethereum Sepolia
6. Return results + on-chain proof

When any external key or DeepFace is missing the service automatically returns **demo** results so the UI stays usable.

## Quick start

```bash
cd server/face-service
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Optional – real mode
cp .env.example .env
# edit .env with your SerpAPI / Cloudinary / wallet keys

uvicorn main:app --host 0.0.0.0 --port 8100 --reload
```

Health check: http://localhost:8100/health

## Endpoints

| Method | Path                  | Description                          |
|--------|-----------------------|--------------------------------------|
| GET    | /health               | Status + mode (real / demo)          |
| POST   | /api/face/detect-crop | Crop face only, return base64        |
| POST   | /api/face/pipeline    | Full pipeline (auto demo fallback)   |
| POST   | /api/face/demo        | Force mock response                  |

All POST endpoints accept `multipart/form-data` with field name `file`.

## Integration with Sentinel

The React page `AIFaceDetection.tsx` calls these endpoints directly (or via a thin Node proxy).  
No existing Sentinel routes, schema or auth logic were modified.
