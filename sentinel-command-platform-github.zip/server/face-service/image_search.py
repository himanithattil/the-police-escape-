"""
Cloudinary upload + SerpAPI Google Lens reverse-image search.
Falls back to empty results when keys are missing (demo mode).
"""
from __future__ import annotations

import os
from typing import Any

import requests
from dotenv import load_dotenv

load_dotenv()

SERPAPI_KEY = os.getenv("SERPAPI_KEY", "").strip()
CLOUDINARY_CLOUD_NAME = os.getenv("CLOUDINARY_CLOUD_NAME", "").strip()
CLOUDINARY_API_KEY = os.getenv("CLOUDINARY_API_KEY", "").strip()
CLOUDINARY_API_SECRET = os.getenv("CLOUDINARY_API_SECRET", "").strip()

_cloudinary_configured = bool(
    CLOUDINARY_CLOUD_NAME and CLOUDINARY_API_KEY and CLOUDINARY_API_SECRET
)

if _cloudinary_configured:
    import cloudinary
    import cloudinary.uploader

    cloudinary.config(
        cloud_name=CLOUDINARY_CLOUD_NAME,
        api_key=CLOUDINARY_API_KEY,
        api_secret=CLOUDINARY_API_SECRET,
    )


def has_real_keys() -> bool:
    """True when both Cloudinary and SerpAPI credentials are present."""
    return _cloudinary_configured and bool(SERPAPI_KEY)


def upload_to_cloudinary(image_path: str) -> str:
    """Upload image and return a public HTTPS URL. Raises if keys missing."""
    if not _cloudinary_configured:
        raise RuntimeError(
            "Cloudinary credentials missing. Set CLOUDINARY_* env vars or use demo mode."
        )
    result = cloudinary.uploader.upload(image_path, folder="face_search")
    return result["secure_url"]


def reverse_image_search(image_url: str) -> list[dict[str, Any]]:
    """
    Call SerpAPI Google Lens and return visual matches.
    Returns empty list when SerpAPI key is absent.
    """
    if not SERPAPI_KEY:
        return []

    params = {
        "engine": "google_lens",
        "url": image_url,
        "api_key": SERPAPI_KEY,
    }
    resp = requests.get("https://serpapi.com/search", params=params, timeout=45)
    resp.raise_for_status()
    data = resp.json()

    matches: list[dict[str, Any]] = []
    for item in data.get("visual_matches", []):
        matches.append(
            {
                "title": item.get("title", ""),
                "link": item.get("link", ""),
                "source": item.get("source", ""),
                "thumbnail": item.get("thumbnail", ""),
            }
        )
    return matches


def find_social_media_post(matches: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Prefer a social-media domain match; otherwise first result."""
    social_domains = (
        "instagram.com",
        "twitter.com",
        "x.com",
        "facebook.com",
        "linkedin.com",
        "tiktok.com",
        "reddit.com",
        "pinterest.com",
    )
    for match in matches:
        link = (match.get("link") or "").lower()
        if any(domain in link for domain in social_domains):
            return match
    return matches[0] if matches else None
