"""
Face detection and cropping using DeepFace (RetinaFace backend).
Returns path to cropped face image or raises ValueError.
"""
from __future__ import annotations

import os
from pathlib import Path

import cv2
import numpy as np

# DeepFace is heavy; import lazily so the service can still start in demo mode
# when models / TensorFlow are missing.


def detect_and_crop_face(
    input_path: str,
    output_dir: str = "temp",
) -> tuple[str, list[float]]:
    """
    Detect the primary face in `input_path`, crop it, and save as JPEG.

    Returns
    -------
    cropped_path : str
        Absolute path to the saved cropped face.
    embedding_placeholder : list[float]
        Placeholder (zeros) – full embedding is computed later during matching.
    """
    os.makedirs(output_dir, exist_ok=True)

    try:
        from deepface import DeepFace
    except ImportError as exc:
        raise RuntimeError(
            "DeepFace is not installed. Run: pip install -r requirements.txt"
        ) from exc

    try:
        faces = DeepFace.extract_faces(
            img_path=input_path,
            detector_backend="retinaface",
            enforce_detection=True,
        )
    except Exception as exc:
        # Fallback to opencv detector if retinaface fails
        try:
            faces = DeepFace.extract_faces(
                img_path=input_path,
                detector_backend="opencv",
                enforce_detection=True,
            )
        except Exception as inner:
            raise ValueError(f"Face detection failed: {inner}") from inner

    if not faces:
        raise ValueError("No face detected in the uploaded image.")

    face_img = faces[0]["face"]

    # DeepFace sometimes returns float images in [0, 1]
    if face_img.max() <= 1.0:
        face_img = (face_img * 255).astype(np.uint8)

    # Convert RGB → BGR for OpenCV write
    if face_img.shape[-1] == 3:
        face_img = cv2.cvtColor(face_img, cv2.COLOR_RGB2BGR)

    cropped_path = str(Path(output_dir) / "cropped_face.jpg")
    cv2.imwrite(cropped_path, face_img)

    return cropped_path, [0.0] * 128
