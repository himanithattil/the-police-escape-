"""
Ethereum Sepolia verification client (manual RLP + eth-keys).
Works only when CONTRACT_ADDRESS and WALLET_PRIVATE_KEY are set.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from typing import Any

import requests
from dotenv import load_dotenv
from eth_abi import encode, decode
from eth_keys import keys
from Crypto.Hash import keccak as keccak_hasher
import rlp

load_dotenv()

SEPOLIA_RPC = os.getenv(
    "SEPOLIA_RPC", "https://ethereum-sepolia-rpc.publicnode.com"
).strip()
CONTRACT_ADDRESS = os.getenv("CONTRACT_ADDRESS", "").strip()
PRIVATE_KEY = os.getenv("WALLET_PRIVATE_KEY", "").strip()
CHAIN_ID = 11155111


def keccak256(data: bytes) -> bytes:
    h = keccak_hasher.new(digest_bits=256)
    h.update(data)
    return h.digest()


def get_selector(signature: str) -> bytes:
    return keccak256(signature.encode())[:4]


STORE_HASH_SELECTOR = get_selector("storeHash(bytes32,string)")
VERIFY_HASH_SELECTOR = get_selector("verifyHash(bytes32)")


def compute_content_hash(post_data: dict) -> str:
    """Deterministic content hash of the discovered post."""
    payload = json.dumps(
        {
            "link": post_data.get("link", ""),
            "source": post_data.get("source", ""),
            "title": post_data.get("title", ""),
        },
        sort_keys=True,
    )
    return "0x" + hashlib.sha256(payload.encode()).hexdigest()


def has_blockchain_keys() -> bool:
    return bool(CONTRACT_ADDRESS and PRIVATE_KEY)


class BlockchainVerifier:
    def __init__(self) -> None:
        if not has_blockchain_keys():
            raise RuntimeError(
                "Blockchain keys missing. Set CONTRACT_ADDRESS and WALLET_PRIVATE_KEY."
            )
        self.private_key = keys.PrivateKey(bytes.fromhex(PRIVATE_KEY.replace("0x", "")))
        self.address = self.private_key.public_key.to_checksum_address()

    def _rpc_call(self, method: str, params: list) -> dict:
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        resp = requests.post(SEPOLIA_RPC, json=payload, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        if "error" in data:
            raise RuntimeError(f"RPC error: {data['error']}")
        return data

    def _get_nonce(self) -> int:
        result = self._rpc_call("eth_getTransactionCount", [self.address, "pending"])
        return int(result["result"], 16)

    def _get_gas_price(self) -> int:
        result = self._rpc_call("eth_gasPrice", [])
        return int(result["result"], 16)

    def _estimate_gas(self, to: str, data: str) -> int:
        try:
            result = self._rpc_call(
                "eth_estimateGas",
                [{"from": self.address, "to": to, "data": data}],
            )
            return int(result["result"], 16)
        except Exception:
            return 200_000  # safe default

    def _send_raw(self, tx_dict: dict) -> str:
        # Build unsigned RLP list
        unsigned_list = [
            tx_dict["nonce"],
            tx_dict["gasPrice"],
            tx_dict["gas"],
            bytes.fromhex(tx_dict["to"][2:]),
            tx_dict["value"],
            bytes.fromhex(tx_dict["data"][2:]),
            CHAIN_ID,
            0,
            0,
        ]
        unsigned_rlp = rlp.encode(unsigned_list)
        tx_hash = keccak256(unsigned_rlp)

        signature = self.private_key.sign_msg_hash(tx_hash)
        rec_id = signature.v if signature.v in (0, 1) else (signature.v - 27)
        v = rec_id + CHAIN_ID * 2 + 35

        signed_list = [
            tx_dict["nonce"],
            tx_dict["gasPrice"],
            tx_dict["gas"],
            bytes.fromhex(tx_dict["to"][2:]),
            tx_dict["value"],
            bytes.fromhex(tx_dict["data"][2:]),
            v,
            signature.r,
            signature.s,
        ]
        raw_tx = "0x" + rlp.encode(signed_list).hex()
        result = self._rpc_call("eth_sendRawTransaction", [raw_tx])
        return result["result"]

    def store_verification(self, post_data: dict) -> str:
        content_hash = compute_content_hash(post_data)
        metadata_uri = post_data.get("link", "")

        hash_bytes = bytes.fromhex(content_hash[2:])
        encoded_args = encode(["bytes32", "string"], [hash_bytes, metadata_uri])
        data = "0x" + STORE_HASH_SELECTOR.hex() + encoded_args.hex()

        nonce = self._get_nonce()
        gas_price = self._get_gas_price()
        gas_limit = self._estimate_gas(CONTRACT_ADDRESS, data) + 50_000

        tx = {
            "nonce": nonce,
            "gasPrice": gas_price,
            "gas": gas_limit,
            "to": CONTRACT_ADDRESS,
            "value": 0,
            "data": data,
        }
        return self._send_raw(tx)

    def verify_on_chain(self, post_data: dict) -> dict[str, Any]:
        content_hash = compute_content_hash(post_data)
        hash_bytes = bytes.fromhex(content_hash[2:])
        encoded_args = encode(["bytes32"], [hash_bytes])
        data = "0x" + VERIFY_HASH_SELECTOR.hex() + encoded_args.hex()

        result = self._rpc_call(
            "eth_call",
            [{"to": CONTRACT_ADDRESS, "data": data}, "latest"],
        )
        raw = result["result"]
        if raw in ("0x", "0x0", ""):
            return {
                "verified": False,
                "content_hash": content_hash,
                "timestamp": 0,
                "submitter": "",
                "metadata_uri": "",
            }

        decoded = decode(
            ["bytes32", "uint256", "address", "string"],
            bytes.fromhex(raw[2:]),
        )
        return {
            "verified": True,
            "content_hash": "0x" + decoded[0].hex(),
            "timestamp": int(decoded[1]),
            "submitter": decoded[2],
            "metadata_uri": decoded[3],
        }
